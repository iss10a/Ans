# Git Folder Uploader — Android

Uploads entire folders from your phone to GitHub, hierarchy preserved, using
the **GitHub REST API** directly. No `git` binary, no desktop, no web uploader.

Built with Kotlin and Jetpack Compose. The folder handling uses the **Storage
Access Framework**, which is what makes this straightforward on Android:
`ACTION_OPEN_DOCUMENT_TREE` plus `takePersistableUriPermission` grants access to
a folder that survives process death and reboot, so nothing has to be copied
into the app and a paused job can resume days later against the original files.

---

## Features

**Selecting**
- Pick a whole folder — sub-folders included, recursively
- Pick many files at once
- Drag and drop from the Files app
- Paste a folder or files copied elsewhere
- A review step showing the file count, total size and every path, with
  per-file checkboxes plus select all / deselect all

**Uploading**
- One commit for thousands of files, via the Git Data API
- **Unchanged files are skipped** — the app computes each file's Git blob SHA-1
  locally and compares it with the remote tree
- Per-file and overall progress, transfer speed, time remaining
- Pause, resume, cancel, retry
- Runs in a foreground service, so backgrounding the app does not kill it
- Auto-resumes when a dropped connection returns
- Conflict handling: replace, skip, or keep both

**Browsing**
- Repository list with filtering
- Navigate any repository tree, any depth

**Presentation**
- Arabic and English, with correct right-to-left layout
- Light, dark, and system theme; Material You colours on Android 12+

---

## Requirements

| | |
|---|---|
| minSdk | 24 (Android 7.0) |
| targetSdk | 34 |
| JDK | 17 |
| Gradle | 8.7 |

---

## Getting the APK

### GitHub Actions — free, no account beyond GitHub

1. Push this repository to GitHub.
2. The **Build APK** workflow runs on every push.
3. Open the run → **Artifacts** → download `git-folder-uploader-apk`.
4. Unzip and install the `.apk`. Allow installation from your browser or file
   manager when Android asks.

### Codemagic

`codemagic.yaml` is included and does the same thing. GitHub Actions is the
simpler route for a personal project, so treat Codemagic as the alternative.

### A note on signing

Both workflows generate a keystore on the runner, so no secret setup is needed
and no key is ever committed. The trade-off: **the signature differs on every
build**, and Android refuses to install an APK over one signed with a different
key. Uninstall the old copy first.

To keep one stable signature, create a keystore once:

```bash
keytool -genkeypair -v -keystore release.jks -alias upload \
  -keyalg RSA -keysize 2048 -validity 10000
base64 -w0 release.jks     # add as the secret KEYSTORE_BASE64
```

Then decode it in the workflow instead of generating one, and set
`KEYSTORE_PASSWORD`, `KEY_ALIAS` and `KEY_PASSWORD` as secrets. The Gradle
config already reads those environment variables.

---

## Signing in

**Personal access token** — GitHub → Settings → Developer settings → Personal
access tokens. Needs the `repo` scope; add `read:user` so your profile appears.
Fine-grained tokens work too: grant *Contents: Read and write* and
*Metadata: Read*.

**OAuth device flow** — create an OAuth app, enable *Device flow*, and paste the
client **ID**. Only the ID is needed; no client secret is compiled into the app,
which would be unsafe in a distributed binary.

The token is kept in `EncryptedSharedPreferences`, falling back to app-private
preferences on devices whose keystore refuses to cooperate.

---

## Architecture

```
app/src/main/java/com/gitfolderuploader/
├── GitApp.kt              Composition root; everything is wired by hand
├── MainActivity.kt        Navigation and the in-app locale override
├── core/                  Logging, Git hashing, formatting, token storage
│   └── net/               GitHubClient: retries, rate limits, paging, progress
├── data/
│   ├── dto/               Wire types
│   └── remote/            GitHubService: every endpoint in one place
├── domain/model/          Repository, Branch, UploadJob, UploadSource, …
├── upload/
│   ├── SafScanner         Recursive SAF walk and local blob hashing
│   ├── UploadEngine       The five-step pipeline
│   ├── UploadManager      Queue, persistence, reachability
│   ├── UploadService      Foreground service and progress notification
│   └── JobStore           One JSON file per job
└── ui/                    Compose screens and theme
```

### How an upload works

Uploading through the *Contents* API would mean one commit per file — unusable
for a folder with thousands of entries. The **Git Data API** is used instead:

1. **Scan** — walk the picked tree with `DocumentsContract`, skipping `.git`,
   `node_modules`, `build`, `.gradle`, `.dart_tool` and friends. Each file's Git
   blob SHA-1 is computed by streaming it in 1 MiB chunks, so memory stays flat.
2. **Compare** — fetch the remote tree once and diff. Identical files are marked
   skipped and never transferred. Differing files are conflicts, resolved with
   the chosen policy.
3. **Upload blobs** — `POST /git/blobs`, four at a time, with retry and
   exponential backoff, reporting bytes written for the per-file bar.
4. **Build the tree** — `POST /git/trees` in chunks of 300 entries, each chunk
   chaining `base_tree` to the previous result.
5. **Commit and push** — `POST /git/commits`, then `PATCH /git/refs/heads/…`.
   If someone else moved the branch meanwhile, the commit is rebuilt on the new
   head and retried. An empty repository gets its branch created instead.

Job state is written to disk after every transition, so quitting mid-upload and
relaunching resumes from the last completed file rather than starting over.

### Why the destination defaults to the repository root

Nesting a project one level deep breaks every tool that only looks at the root:
Codemagic reads `codemagic.yaml` there, Flutter needs `pubspec.yaml` there,
GitHub Actions reads `.github/workflows/` there. Pushing from a computer lands
files at the root, and the default matches that. The review sheet warns if a
root-anchored file would end up in a subfolder.

---

## Debugging

Selection and upload problems are logged with fixed tags:

```bash
adb logcat -s GFU-picker GFU-upload GFU-net
```

`GFU-picker` answers the questions that matter when a folder misbehaves: was the
permission persisted, how many direct children were seen, how many files the
scan produced, and exactly which step failed.

---

## Limits

- Individual files must stay under 100 MB — a GitHub blob limit, not an app one.
- GitHub truncates a recursive tree past roughly 100,000 entries; the app logs
  this rather than silently comparing an incomplete index.
- Android caps persisted URI permissions (128 on most builds). Beyond that the
  oldest grants are dropped and those folders need re-picking.

## License

MIT.
