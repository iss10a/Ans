package com.gitfolderuploader.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class GitHubUser(
    val login: String,
    val name: String? = null,
    val avatarUrl: String? = null,
    val publicRepos: Int = 0,
    val privateRepos: Int = 0
) {
    val displayName: String get() = name?.takeIf { it.isNotBlank() } ?: login
}

/** owner + name, the pair every endpoint needs. */
@Serializable
data class RepoRef(val owner: String, val name: String) {
    val fullName: String get() = "$owner/$name"

    companion object {
        fun parse(fullName: String): RepoRef? {
            val parts = fullName.split("/")
            if (parts.size != 2 || parts.any { it.isBlank() }) return null
            return RepoRef(parts[0], parts[1])
        }
    }
}

@Serializable
data class Repository(
    val id: Long,
    val name: String,
    val fullName: String,
    val owner: String,
    val description: String? = null,
    val isPrivate: Boolean = false,
    val defaultBranch: String = "main",
    val canPush: Boolean = true,
    val updatedAt: String? = null,
    val language: String? = null,
    val stars: Int = 0
) {
    val ref: RepoRef get() = RepoRef(owner, name)
}

@Serializable
data class Branch(val name: String, val sha: String, val isProtected: Boolean = false)

/** One entry inside a repository directory listing. */
@Serializable
data class RepoItem(
    val name: String,
    val path: String,
    val sha: String,
    val size: Long,
    val isDirectory: Boolean,
    val downloadUrl: String? = null
)

@Serializable
data class GitCommitRef(val sha: String, val treeSha: String, val message: String = "")

@Serializable
data class TreeEntry(
    val path: String,
    val mode: String,
    val type: String,
    val sha: String?,
    val size: Long = 0
) {
    companion object {
        /** A regular file entry pointing at an existing blob. */
        fun blob(path: String, sha: String) =
            TreeEntry(path = path, mode = "100644", type = "blob", sha = sha)
    }
}

@Serializable
data class GitTree(val sha: String, val entries: List<TreeEntry>, val truncated: Boolean) {
    /** Path to blob-SHA map, used to skip files that are already up to date. */
    fun blobIndex(): Map<String, String> =
        entries.filter { it.type == "blob" && it.sha != null }.associate { it.path to it.sha!! }
}

/** Result of starting the OAuth device flow. */
@Serializable
data class DeviceCodeSession(
    val deviceCode: String,
    val userCode: String,
    val verificationUri: String,
    val intervalSeconds: Long,
    val expiresInSeconds: Long
)
