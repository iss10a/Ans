package com.gitfolderuploader.core

import java.util.Locale
import kotlin.math.abs
import kotlin.math.ln
import kotlin.math.pow

object Formatters {

    fun size(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val units = arrayOf("KB", "MB", "GB", "TB")
        val exponent = (ln(bytes.toDouble()) / ln(1024.0)).toInt().coerceIn(1, units.size)
        val value = bytes / 1024.0.pow(exponent.toDouble())
        return String.format(Locale.US, "%.1f %s", value, units[exponent - 1])
    }

    fun speed(bytesPerSecond: Double): String = size(bytesPerSecond.toLong()) + "/s"

    /** Compact duration: 45s, 3m 20s, 1h 05m. */
    fun duration(seconds: Double): String {
        val total = abs(seconds).toLong()
        return when {
            total < 60 -> "${total}s"
            total < 3600 -> "${total / 60}m ${total % 60}s"
            else -> String.format(Locale.US, "%dh %02dm", total / 3600, (total % 3600) / 60)
        }
    }

    fun percent(fraction: Double): String =
        String.format(Locale.US, "%.0f%%", (fraction.coerceIn(0.0, 1.0)) * 100)
}
