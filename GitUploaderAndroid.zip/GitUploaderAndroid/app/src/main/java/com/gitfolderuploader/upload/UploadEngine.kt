package com.gitfolderuploader.upload

import android.content.Context
import android.net.Uri
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.core.net.ApiError
import com.gitfolderuploader.data.remote.GitHubService
import com.gitfolderuploader.domain.model.ConflictPolicy
import com.gitfolderuploader.domain.model.FileState
import com.gitfolderuploader.domain.model.JobState
import com.gitfolderuploader.domain.model.RepoRef
import com.gitfolderuploader.domain.model.TreeEntry
import com.gitfolderuploader.domain.model.UploadFile
import com.gitfolderuploader.domain.model.UploadJob
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.coroutineContext

/**
 * Runs one [UploadJob] to completion.
 *
 * Pipeline
 * --------
 * 1. Scan every source through SAF, hashing each file locally.
 * 2. Read the remote tree once and diff it. Identical files are marked skipped
 *    and never transferred; differing files are conflicts, resolved with the
 *    job's [ConflictPolicy].
 * 3. Upload the remaining files as blobs with bounded concurrency, retries and
 *    live per-file byte progress.
 * 4. Build the tree in chunks, chaining `base_tree`, so thousands of files stay
 *    inside GitHub's request limits.
 * 5. Create the commit and fast-forward the branch, retrying if someone else
 *    moved it meanwhile.
 */
class UploadEngine(
    private val context: Context,
    private val service: GitHubService
) {

    private val concurrency = 4
    private val treeChunkSize = 300
    private val attemptsPerFile = 3
    private val pushAttempts = 3
    private val progressTickMillis = 400L

    private data class Head(val commitSha: String, val treeSha: String)

    /**
     * @param onUpdate called whenever the job changes; the caller persists and
     *   publishes it.
     */
    suspend fun execute(job: UploadJob, onUpdate: (UploadJob) -> Unit): UploadJob {
        var current = job

        fun publish(mutate: (UploadJob) -> Unit) {
            mutate(current)
            current.updatedAt = System.currentTimeMillis()
            onUpdate(current)
        }

        try {
            // ---- 1. Scan ---------------------------------------------------
            if (current.files.isEmpty()) {
                publish { it.state = JobState.SCANNING }

                val prefixNeeded = current.sources.size > 1
                val scan = withContext(Dispatchers.IO) {
                    SafScanner.scan(context, current.sources, prefixNeeded)
                }
                if (scan.files.isEmpty()) {
                    publish {
                        it.state = JobState.FAILED
                        it.lastError = "Nothing readable was found in the selection."
                    }
                    return current
                }
                val warnings = buildList {
                    if (scan.oversized.isNotEmpty()) {
                        add("Too large for GitHub: " + scan.oversized.take(5).joinToString(", "))
                    }
                    if (scan.unreadable.isNotEmpty()) {
                        add("Unreadable: " + scan.unreadable.take(5).joinToString(", "))
                    }
                }
                publish {
                    it.files = scan.files
                    it.lastError = warnings.takeIf { w -> w.isNotEmpty() }?.joinToString("\n")
                }
            }

            coroutineContext.ensureActive()

            // ---- 2. Diff against the remote --------------------------------
            publish { it.state = JobState.COMPARING }
            val head = currentHead(current.repo, current.branch)
            val remoteIndex = remoteBlobIndex(current.repo, head)

            publish {
                var files = markConflicts(it.files, remoteIndex, it.remoteRoot)
                files = applyPolicy(it.conflictPolicy, files, remoteIndex, it.remoteRoot)
                it.files = files
            }
            AppLog.upload("Diff: ${current.skippedFiles} unchanged, ${current.conflictCount} conflicting")

            coroutineContext.ensureActive()

            // ---- 3. Upload blobs -------------------------------------------
            publish {
                it.state = JobState.UPLOADING
                it.bytesSentBeforeRun = it.transferredBytes
                it.transferStartedAt = System.currentTimeMillis()
            }
            uploadBlobs(current, onUpdate)

            if (current.failedFiles > 0) {
                publish {
                    it.state = JobState.FAILED
                    it.lastError = "${current.failedFiles} file(s) could not be uploaded."
                }
                return current
            }

            // ---- 4/5. Tree, commit, push -----------------------------------
            val entries = current.files.mapNotNull { file ->
                file.remoteBlobSha?.let { TreeEntry.blob(file.remotePath(current.remoteRoot), it) }
            }
            if (entries.isEmpty()) {
                // Everything was already up to date. Nothing to commit is success.
                publish {
                    it.lastError = null
                    it.resultCommitSha = head?.commitSha
                    it.state = JobState.COMPLETED
                }
                return current
            }

            val commitSha = landCommit(
                repo = current.repo,
                branch = current.branch,
                message = current.commitMessage,
                entries = entries,
                publish = ::publish
            )
            publish {
                it.resultCommitSha = commitSha
                it.lastError = null
                it.state = JobState.COMPLETED
            }
            AppLog.upload("Job ${current.id} committed $commitSha")
            return current

        } catch (cancel: CancellationException) {
            publish { it.state = JobState.PAUSED }
            return current
        } catch (error: Throwable) {
            val message = error.message ?: error.toString()
            AppLog.uploadError("Job ${current.id} failed: $message", error)
            publish {
                it.lastError = message
                it.state = JobState.FAILED
            }
            return current
        }
    }

    // ------------------------------------------------------------ Diffing

    /**
     * Marks files that already exist remotely.
     *
     * A byte-identical file is not a conflict — it is skipped immediately,
     * which is what makes re-uploading a large folder fast.
     */
    fun markConflicts(
        files: List<UploadFile>,
        remoteIndex: Map<String, String>,
        remoteRoot: String
    ): List<UploadFile> = files.map { file ->
        val remote = remoteIndex[file.remotePath(remoteRoot)]
        when {
            remote == null -> file.copy(hasConflict = false)
            remote == file.gitSha -> file.copy(
                hasConflict = false,
                state = if (file.state == FileState.PENDING) FileState.SKIPPED else file.state,
                remoteBlobSha = file.gitSha
            )
            else -> file.copy(hasConflict = true)
        }
    }

    /**
     * Applies the chosen policy to conflicting files.
     *
     * `SKIP` clears the blob SHA so the path is left out of the tree entirely,
     * which keeps the remote copy intact — the tree is chained onto the current
     * head, so an omitted path simply stays as it is.
     */
    fun applyPolicy(
        policy: ConflictPolicy,
        files: List<UploadFile>,
        remoteIndex: Map<String, String>,
        remoteRoot: String
    ): List<UploadFile> {
        val taken = remoteIndex.keys.toMutableSet()
        files.forEach { taken += it.remotePath(remoteRoot) }

        return files.map { file ->
            if (!file.hasConflict) return@map file
            when (policy) {
                ConflictPolicy.REPLACE -> file.copy(
                    renamedRelativePath = null,
                    state = if (file.state == FileState.SKIPPED) FileState.PENDING else file.state,
                    remoteBlobSha = null
                )

                ConflictPolicy.SKIP -> file.copy(
                    state = FileState.SKIPPED,
                    remoteBlobSha = null,
                    renamedRelativePath = null
                )

                ConflictPolicy.RENAME -> {
                    val currentRemote = file.remotePath(remoteRoot)
                    val free = SafScanner.freePath(currentRemote, taken)
                    taken += free
                    val cleanRoot = remoteRoot.trim('/', ' ')
                    val relative = if (cleanRoot.isNotEmpty() && free.startsWith("$cleanRoot/")) {
                        free.removePrefix("$cleanRoot/")
                    } else {
                        free
                    }
                    file.copy(
                        renamedRelativePath = relative,
                        state = if (file.state == FileState.SKIPPED) FileState.PENDING else file.state,
                        remoteBlobSha = null
                    )
                }
            }
        }
    }

    private suspend fun currentHead(repo: RepoRef, branch: String): Head? = try {
        val sha = service.reference(repo, branch)
        val commit = service.commit(repo, sha)
        Head(commit.sha, commit.treeSha)
    } catch (error: ApiError.NotFound) {
        null // Empty repository, or the branch does not exist yet.
    }

    private suspend fun remoteBlobIndex(repo: RepoRef, head: Head?): Map<String, String> {
        if (head == null) return emptyMap()
        return try {
            val tree = service.tree(repo, head.treeSha, recursive = true)
            if (tree.truncated) {
                AppLog.upload("Remote tree truncated; some files may be re-uploaded")
            }
            tree.blobIndex()
        } catch (error: ApiError.NotFound) {
            emptyMap()
        }
    }

    // ------------------------------------------------------------ Uploading

    /**
     * Uploads pending files with bounded concurrency.
     *
     * OkHttp reports write progress from its own threads, so byte counts land
     * in a concurrent map and a ticker publishes them; the job value itself is
     * only ever mutated from this coroutine.
     */
    private suspend fun uploadBlobs(job: UploadJob, onUpdate: (UploadJob) -> Unit) = coroutineScope {
        val queue = job.files.indices.filter {
            val state = job.files[it].state
            state == FileState.PENDING || state == FileState.UPLOADING || state == FileState.FAILED
        }.sortedBy { job.files[it].size } // Smallest first: progress feels responsive.

        if (queue.isEmpty()) return@coroutineScope

        val liveBytes = ConcurrentHashMap<Int, Long>()
        val semaphore = Semaphore(concurrency)
        val repo = job.repo

        val ticker = launch {
            while (isActive) {
                delay(progressTickMillis)
                var changed = false
                liveBytes.forEach { (index, bytes) ->
                    val file = job.files.getOrNull(index) ?: return@forEach
                    if (file.state == FileState.UPLOADING) {
                        file.bytesSent = minOf(bytes, file.size)
                        changed = true
                    }
                }
                if (changed) {
                    job.updatedAt = System.currentTimeMillis()
                    onUpdate(job)
                }
            }
        }

        try {
            val workers = queue.map { index ->
                launch(Dispatchers.IO) {
                    semaphore.withPermit {
                        val file = job.files[index]
                        file.state = FileState.UPLOADING
                        file.bytesSent = 0

                        val outcome = uploadOne(repo, file) { sent ->
                            liveBytes[index] = sent
                        }
                        liveBytes.remove(index)

                        if (outcome.sha != null) {
                            file.remoteBlobSha = outcome.sha
                            file.state = FileState.UPLOADED
                            file.bytesSent = file.size
                            file.errorMessage = null
                        } else {
                            file.state = FileState.FAILED
                            file.errorMessage = outcome.error
                            file.bytesSent = 0
                            file.attempts += 1
                        }
                        job.updatedAt = System.currentTimeMillis()
                        onUpdate(job)
                    }
                }
            }
            workers.forEach { it.join() }
        } finally {
            ticker.cancel()
        }
    }

    private data class BlobOutcome(val sha: String?, val error: String?)

    /** Uploads one file, retrying transient failures with exponential backoff. */
    private suspend fun uploadOne(
        repo: RepoRef,
        file: UploadFile,
        onBytes: (Long) -> Unit
    ): BlobOutcome {
        var lastError: String? = null

        for (attempt in 0 until attemptsPerFile) {
            coroutineContext.ensureActive()
            try {
                val bytes = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(Uri.parse(file.uri))?.use { it.readBytes() }
                } ?: return BlobOutcome(null, "The file could not be opened.")

                val sha = service.createBlob(repo, bytes) { fraction ->
                    onBytes((fraction * file.size).toLong())
                }
                return BlobOutcome(sha, null)

            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: ApiError) {
                lastError = error.message
                onBytes(0)
                if (!error.isRetryable || attempt == attemptsPerFile - 1) break
                delay((1L shl attempt) * 1000)
            } catch (error: Throwable) {
                lastError = error.message ?: error.toString()
                break
            }
        }
        return BlobOutcome(null, lastError ?: "Unknown error")
    }

    // -------------------------------------------------------------- Commit

    /**
     * Builds the tree, creates the commit and moves the branch.
     *
     * Tree creation chains `base_tree` across chunks, so a folder with tens of
     * thousands of entries commits without ever sending an oversized body.
     */
    private suspend fun landCommit(
        repo: RepoRef,
        branch: String,
        message: String,
        entries: List<TreeEntry>,
        publish: ((UploadJob) -> Unit) -> Unit
    ): String {
        var attempt = 0
        while (true) {
            coroutineContext.ensureActive()
            attempt++

            val head = currentHead(repo, branch)

            publish { it.state = JobState.BUILDING_TREE }
            var treeSha: String? = head?.treeSha
            entries.chunked(treeChunkSize).forEach { chunk ->
                coroutineContext.ensureActive()
                treeSha = service.createTree(repo, treeSha, chunk)
            }
            val finalTree = treeSha ?: throw ApiError.Validation("No tree was produced.")

            publish { it.state = JobState.COMMITTING }
            val parents = head?.let { listOf(it.commitSha) } ?: emptyList()
            val commitSha = service.createCommit(repo, message, finalTree, parents)

            try {
                if (head == null) {
                    service.createBranch(repo, branch, commitSha)
                } else {
                    service.updateBranch(repo, branch, commitSha, force = false)
                }
                return commitSha
            } catch (error: ApiError) {
                // A concurrent push moved the branch: rebuild on the new head.
                val isRace = error is ApiError.Validation || error is ApiError.Conflict
                if (!isRace || attempt >= pushAttempts) throw error
                AppLog.upload("Push rejected; retrying on the updated head (attempt $attempt)")
            }
        }
    }
}
