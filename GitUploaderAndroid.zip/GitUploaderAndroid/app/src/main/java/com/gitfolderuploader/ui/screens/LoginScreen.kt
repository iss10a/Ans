package com.gitfolderuploader.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.gitfolderuploader.GitApp
import com.gitfolderuploader.R
import com.gitfolderuploader.core.net.ApiError
import com.gitfolderuploader.domain.model.DeviceCodeSession
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen(app: GitApp, onSignedIn: () -> Unit) {

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var mode by remember { mutableStateOf(0) } // 0 = token, 1 = OAuth
    var token by remember { mutableStateOf("") }
    var clientId by remember { mutableStateOf(app.tokens.oauthClientId.orEmpty()) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var session by remember { mutableStateOf<DeviceCodeSession?>(null) }

    fun signIn(newToken: String) {
        scope.launch {
            busy = true
            error = null
            app.tokens.token = newToken
            runCatching { app.service.currentUser() }
                .onSuccess { onSignedIn() }
                .onFailure {
                    app.tokens.clear()
                    error = it.message
                }
            busy = false
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text(stringResource(R.string.auth_title)) }) }) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = stringResource(R.string.auth_subtitle),
                style = MaterialTheme.typography.bodyMedium
            )

            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = mode == 0,
                    onClick = { mode = 0 },
                    shape = SegmentedButtonDefaults.itemShape(0, 2)
                ) { Text(stringResource(R.string.auth_mode_token)) }

                SegmentedButton(
                    selected = mode == 1,
                    onClick = { mode = 1 },
                    shape = SegmentedButtonDefaults.itemShape(1, 2)
                ) { Text(stringResource(R.string.auth_mode_oauth)) }
            }

            if (mode == 0) {
                OutlinedTextField(
                    value = token,
                    onValueChange = { token = it },
                    label = { Text(stringResource(R.string.auth_token_label)) },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = stringResource(R.string.auth_token_hint),
                    style = MaterialTheme.typography.bodySmall
                )
                Button(
                    onClick = { signIn(token.trim()) },
                    enabled = token.isNotBlank() && !busy,
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.auth_sign_in)) }
            } else {
                OutlinedTextField(
                    value = clientId,
                    onValueChange = { clientId = it },
                    label = { Text(stringResource(R.string.auth_client_id)) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = stringResource(R.string.auth_oauth_hint),
                    style = MaterialTheme.typography.bodySmall
                )

                val activeSession = session
                if (activeSession == null) {
                    Button(
                        onClick = {
                            scope.launch {
                                busy = true
                                error = null
                                app.tokens.oauthClientId = clientId.trim()
                                runCatching { app.service.startDeviceFlow(clientId.trim()) }
                                    .onSuccess { session = it }
                                    .onFailure { error = it.message }
                                busy = false
                            }
                        },
                        enabled = clientId.isNotBlank() && !busy,
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.auth_device_start)) }
                } else {
                    DeviceCodePanel(
                        session = activeSession,
                        onCopy = { copyToClipboard(context, activeSession.userCode) },
                        onOpen = { openUrl(context, activeSession.verificationUri) },
                        onCancel = { session = null }
                    )

                    // Polls until GitHub reports approval, honouring slow_down.
                    androidx.compose.runtime.LaunchedEffect(activeSession.deviceCode) {
                        var interval = activeSession.intervalSeconds
                        val deadline = System.currentTimeMillis() + activeSession.expiresInSeconds * 1000
                        while (System.currentTimeMillis() < deadline) {
                            delay(interval * 1000)
                            val outcome = runCatching {
                                app.service.pollDeviceToken(clientId.trim(), activeSession.deviceCode)
                            }
                            outcome.onSuccess { granted ->
                                session = null
                                signIn(granted)
                                return@LaunchedEffect
                            }
                            val failure = outcome.exceptionOrNull()
                            when (failure) {
                                is ApiError.DeviceFlowPending -> Unit
                                is ApiError.DeviceFlowSlowDown -> interval = failure.seconds + 1
                                is ApiError.DeviceFlowExpired,
                                is ApiError.DeviceFlowDenied -> {
                                    error = failure.message
                                    session = null
                                    return@LaunchedEffect
                                }
                                else -> Unit
                            }
                        }
                        error = context.getString(R.string.auth_device_expired)
                        session = null
                    }
                }
            }

            if (busy) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center
                ) { CircularProgressIndicator() }
            }

            error?.let {
                Text(text = it, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DeviceCodePanel(
    session: DeviceCodeSession,
    onCopy: () -> Unit,
    onOpen: () -> Unit,
    onCancel: () -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = stringResource(R.string.auth_device_instructions),
                style = MaterialTheme.typography.bodyMedium
            )
            Text(
                text = session.userCode,
                style = MaterialTheme.typography.headlineMedium,
                fontFamily = FontFamily.Monospace
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = onCopy) { Text(stringResource(R.string.common_copy)) }
                Button(onClick = onOpen) { Text(stringResource(R.string.auth_device_open)) }
            }
            OutlinedButton(onClick = onCancel) { Text(stringResource(R.string.common_cancel)) }
        }
    }
}

private fun copyToClipboard(context: Context, text: String) {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    manager.setPrimaryClip(ClipData.newPlainText("code", text))
}

private fun openUrl(context: Context, url: String) {
    runCatching {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    }
}
