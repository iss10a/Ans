package com.gitfolderuploader.core.net

import com.gitfolderuploader.core.AppLog
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.Headers
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okio.BufferedSink
import java.io.IOException
import java.util.concurrent.TimeUnit
import kotlin.math.pow
import kotlin.random.Random

/** Snapshot of GitHub's rate-limit headers, shown in Settings. */
data class RateLimit(
    val limit: Int = 0,
    val remaining: Int = 0,
    val resetEpochSeconds: Long = 0
)

/** A response body together with the paging link header. */
data class ApiResponse(val body: String, val nextPageUrl: String?)

/**
 * Executes GitHub REST calls.
 *
 * Retries transient failures with exponential backoff and jitter, tracks the
 * rate limit, and can report how much of a request body has been written so a
 * blob upload gets a real progress bar.
 */
class GitHubClient(private val tokenProvider: () -> String?) {

    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        explicitNulls = false
    }

    @Volatile
    var rateLimit: RateLimit = RateLimit()
        private set

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(300, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    private val maxRetries = 3

    suspend fun request(
        url: String,
        method: String = "GET",
        body: String? = null,
        accept: String = "application/vnd.github+json",
        onProgress: ((Double) -> Unit)? = null
    ): ApiResponse = withContext(Dispatchers.IO) {
        var attempt = 0
        var lastError: ApiError = ApiError.Transport("No attempt made")

        while (attempt <= maxRetries) {
            try {
                return@withContext performOnce(url, method, body, accept, onProgress)
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: ApiError) {
                lastError = error
                if (!error.isRetryable || attempt == maxRetries) throw error
                val backoff = (2.0.pow(attempt) * 500).toLong() + Random.nextLong(0, 250)
                val wait = (error as? ApiError.RateLimited)?.retryAfterSeconds?.times(1000) ?: backoff
                AppLog.net("Retrying $method $url in ${wait}ms (attempt ${attempt + 1})")
                delay(wait)
                attempt++
            }
        }
        throw lastError
    }

    /** Follows `Link: rel="next"` until every page is collected. */
    suspend fun requestAllPages(firstUrl: String): List<String> {
        val pages = mutableListOf<String>()
        var next: String? = firstUrl
        var guard = 0
        while (next != null && guard < 100) {
            val response = request(next)
            pages += response.body
            next = response.nextPageUrl
            guard++
        }
        return pages
    }

    private fun performOnce(
        url: String,
        method: String,
        body: String?,
        accept: String,
        onProgress: ((Double) -> Unit)?
    ): ApiResponse {
        val requestBody = body?.let { payload ->
            val bytes = payload.toByteArray(Charsets.UTF_8)
            ProgressRequestBody(bytes, onProgress)
        }

        val builder = Request.Builder()
            .url(url)
            .method(method, requestBody)
            .header("Accept", accept)
            .header("X-GitHub-Api-Version", "2022-11-28")
            .header("User-Agent", "GitFolderUploader-Android")

        if (body != null) builder.header("Content-Type", "application/json")
        tokenProvider()?.let { builder.header("Authorization", "Bearer $it") }

        try {
            client.newCall(builder.build()).execute().use { response ->
                captureRateLimit(response.headers)
                val text = response.body?.string().orEmpty()

                if (response.isSuccessful) {
                    return ApiResponse(text, nextPageUrl(response.headers))
                }
                throw mapFailure(response.code, response.headers, text)
            }
        } catch (error: IOException) {
            throw ApiError.Transport(error.message ?: "Network error")
        }
    }

    private fun captureRateLimit(headers: Headers) {
        val limit = headers["X-RateLimit-Limit"]?.toIntOrNull() ?: return
        rateLimit = RateLimit(
            limit = limit,
            remaining = headers["X-RateLimit-Remaining"]?.toIntOrNull() ?: 0,
            resetEpochSeconds = headers["X-RateLimit-Reset"]?.toLongOrNull() ?: 0
        )
    }

    private fun nextPageUrl(headers: Headers): String? {
        val link = headers["Link"] ?: return null
        // Format: <https://…?page=2>; rel="next", <https://…?page=9>; rel="last"
        return link.split(",")
            .map { it.trim() }
            .firstOrNull { it.endsWith("rel=\"next\"") }
            ?.substringAfter("<")
            ?.substringBefore(">")
    }

    private fun mapFailure(status: Int, headers: Headers, body: String): ApiError {
        val detail = extractMessage(body)
        return when {
            status == 401 -> ApiError.Unauthorized()
            status == 403 && headers["X-RateLimit-Remaining"] == "0" ->
                ApiError.RateLimited(headers["Retry-After"]?.toLongOrNull())
            status == 403 -> ApiError.Forbidden(detail)
            status == 404 -> ApiError.NotFound()
            status == 409 -> ApiError.Conflict(detail)
            status == 422 -> ApiError.Validation(detail)
            status == 429 -> ApiError.RateLimited(headers["Retry-After"]?.toLongOrNull())
            status >= 500 -> ApiError.Server(status, detail)
            else -> ApiError.Server(status, detail)
        }
    }

    /** GitHub wraps errors as `{"message": "..."}`. */
    private fun extractMessage(body: String): String? = runCatching {
        json.parseToJsonElement(body).jsonObject["message"]?.jsonPrimitive?.content
    }.getOrNull()

    inline fun <reified T> decode(body: String): T = runCatching {
        json.decodeFromString<T>(body)
    }.getOrElse { throw ApiError.Decoding(it.message ?: "decode failed") }

    fun parse(body: String): JsonElement = json.parseToJsonElement(body)
}

/**
 * Request body that reports progress as it is written.
 *
 * OkHttp calls [writeTo] on the network thread, so the callback must not touch
 * UI state directly — the upload engine funnels it through a lock-protected box.
 */
private class ProgressRequestBody(
    private val bytes: ByteArray,
    private val onProgress: ((Double) -> Unit)?
) : RequestBody() {

    private val chunk = 64 * 1024

    override fun contentType() = "application/json".toMediaType()

    override fun contentLength(): Long = bytes.size.toLong()

    override fun writeTo(sink: BufferedSink) {
        if (onProgress == null) {
            sink.write(bytes)
            return
        }
        var written = 0
        while (written < bytes.size) {
            val count = minOf(chunk, bytes.size - written)
            sink.write(bytes, written, count)
            written += count
            onProgress.invoke(written.toDouble() / bytes.size)
        }
    }
}
