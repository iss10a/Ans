package com.gitfolderuploader.upload

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import com.gitfolderuploader.core.AppLog

/**
 * Watches connectivity so an upload interrupted by a dropped connection
 * restarts on its own once the network is back.
 */
class NetworkWatcher(context: Context) {

    private val manager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private var callback: ConnectivityManager.NetworkCallback? = null

    /** Starts optimistic so nothing is blocked before the first callback. */
    @Volatile
    var isOnline: Boolean = true
        private set

    fun start(onAvailable: () -> Unit, onLost: () -> Unit) {
        if (callback != null) return

        val watcher = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                if (isOnline) return
                isOnline = true
                AppLog.upload("Connectivity restored")
                onAvailable()
            }

            override fun onLost(network: Network) {
                if (!isOnline) return
                isOnline = false
                AppLog.upload("Connectivity lost")
                onLost()
            }
        }

        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .build()

        runCatching { manager.registerNetworkCallback(request, watcher) }
            .onSuccess { callback = watcher }
            .onFailure { AppLog.uploadError("Could not register the network callback", it) }
    }

    fun stop() {
        callback?.let { runCatching { manager.unregisterNetworkCallback(it) } }
        callback = null
    }
}
