package com.gitfolderuploader.core

import android.content.Context

/** Non-secret user preferences: language and theme. */
class Settings(context: Context) {

    private val prefs = context.getSharedPreferences("gfu_settings", Context.MODE_PRIVATE)

    /** "system", "en" or "ar". */
    var language: String
        get() = prefs.getString(KEY_LANGUAGE, "system") ?: "system"
        set(value) = prefs.edit().putString(KEY_LANGUAGE, value).apply()

    /** "system", "light" or "dark". */
    var theme: String
        get() = prefs.getString(KEY_THEME, "system") ?: "system"
        set(value) = prefs.edit().putString(KEY_THEME, value).apply()

    private companion object {
        const val KEY_LANGUAGE = "language"
        const val KEY_THEME = "theme"
    }
}
