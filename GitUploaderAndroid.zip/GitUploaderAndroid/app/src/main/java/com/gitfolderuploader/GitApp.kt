package com.gitfolderuploader

import android.app.Application
import com.gitfolderuploader.core.Settings
import com.gitfolderuploader.core.TokenStore
import com.gitfolderuploader.core.net.GitHubClient
import com.gitfolderuploader.data.remote.GitHubService
import com.gitfolderuploader.upload.JobStore
import com.gitfolderuploader.upload.UploadEngine
import com.gitfolderuploader.upload.UploadManager

/**
 * Composition root.
 *
 * Everything is constructed once here and read through `application as GitApp`.
 * A dependency-injection framework would add a build step and a code generator
 * for a graph this small, so it is wired by hand on purpose.
 */
class GitApp : Application() {

    lateinit var tokens: TokenStore
        private set
    lateinit var settings: Settings
        private set
    lateinit var service: GitHubService
        private set
    lateinit var client: GitHubClient
        private set
    lateinit var uploads: UploadManager
        private set

    override fun onCreate() {
        super.onCreate()

        tokens = TokenStore(this)
        settings = Settings(this)
        client = GitHubClient { tokens.token }
        service = GitHubService(client)

        uploads = UploadManager(
            context = this,
            engine = UploadEngine(this, service),
            store = JobStore(this)
        )
        uploads.start()
    }
}
