package com.gitfolderuploader.upload

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.gitfolderuploader.GitApp
import com.gitfolderuploader.MainActivity
import com.gitfolderuploader.R
import com.gitfolderuploader.core.Formatters
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Keeps the process alive while an upload runs.
 *
 * Android will freeze or kill a backgrounded app mid-transfer; a foreground
 * service with a visible notification is the sanctioned way to finish long
 * network work, and the notification doubles as live progress.
 */
class UploadService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var observer: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground(buildNotification(getString(R.string.upload_preparing), 0, true))
        observeProgress()
        // Restarting with no queue is harmless: the manager stops the service.
        return START_STICKY
    }

    private fun startInForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun observeProgress() {
        if (observer != null) return
        val manager = (application as GitApp).uploads

        observer = scope.launch {
            manager.jobs.collectLatest { jobs ->
                val running = jobs.firstOrNull { it.id == manager.runningJobId.value }
                if (running == null) {
                    if (jobs.none { !it.state.isTerminal }) stopSelf()
                    return@collectLatest
                }

                val percent = (running.fraction * 100).toInt().coerceIn(0, 100)
                val speed = running.bytesPerSecond?.let { " · " + Formatters.speed(it) } ?: ""
                val remaining = running.secondsRemaining?.let { " · " + Formatters.duration(it) } ?: ""
                val text = "${running.settledFiles}/${running.totalFiles}$speed$remaining"

                notificationManager().notify(
                    NOTIFICATION_ID,
                    buildNotification("${running.displayName} — $text", percent, false)
                )
            }
        }
    }

    private fun buildNotification(text: String, percent: Int, indeterminate: Boolean): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.upload_notification_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .setProgress(100, percent, indeterminate)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val channel = NotificationChannel(
            CHANNEL_ID,
            getString(R.string.upload_channel_name),
            NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = getString(R.string.upload_channel_description)
            setShowBadge(false)
        }
        notificationManager().createNotificationChannel(channel)
    }

    private fun notificationManager() =
        getSystemService(NOTIFICATION_SERVICE) as NotificationManager

    override fun onDestroy() {
        observer?.cancel()
        scope.cancel()
        super.onDestroy()
    }

    private companion object {
        const val CHANNEL_ID = "uploads"
        const val NOTIFICATION_ID = 4711
    }
}
