package com.gitfolderuploader.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gitfolderuploader.GitApp
import com.gitfolderuploader.R
import com.gitfolderuploader.core.Formatters
import com.gitfolderuploader.domain.model.JobState
import com.gitfolderuploader.domain.model.Repository
import com.gitfolderuploader.domain.model.UploadJob
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    app: GitApp,
    onOpenRepository: (fullName: String, branch: String, path: String) -> Unit,
    onOpenJob: (String) -> Unit,
    onSignOut: () -> Unit,
    onThemeChanged: (String) -> Unit,
    onLanguageChanged: (String) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    val jobs by app.uploads.jobs.collectAsState()
    val activeCount = jobs.count { !it.state.isTerminal }

    Scaffold(
        topBar = {
            TopAppBar(title = {
                Text(
                    when (tab) {
                        0 -> stringResource(R.string.tab_repositories)
                        1 -> stringResource(R.string.tab_uploads)
                        else -> stringResource(R.string.tab_settings)
                    }
                )
            })
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Default.Folder, null) },
                    label = { Text(stringResource(R.string.tab_repositories)) }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Default.CloudUpload, null) },
                    label = {
                        Text(
                            if (activeCount > 0) {
                                stringResource(R.string.tab_uploads) + " ($activeCount)"
                            } else {
                                stringResource(R.string.tab_uploads)
                            }
                        )
                    }
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Icon(Icons.Default.Settings, null) },
                    label = { Text(stringResource(R.string.tab_settings)) }
                )
            }
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (tab) {
                0 -> RepositoriesTab(app, onOpenRepository)
                1 -> UploadsTab(app, onOpenJob)
                else -> SettingsTab(app, onSignOut, onThemeChanged, onLanguageChanged)
            }
        }
    }
}

@Composable
private fun RepositoriesTab(
    app: GitApp,
    onOpen: (String, String, String) -> Unit
) {
    val scope = rememberCoroutineScope()
    var repositories by remember { mutableStateOf<List<Repository>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        loading = true
        runCatching { app.service.listRepositories() }
            .onSuccess { repositories = it; error = null }
            .onFailure { error = it.message }
        loading = false
    }

    val filtered = remember(repositories, query) {
        if (query.isBlank()) repositories
        else repositories.filter { it.fullName.contains(query, ignoreCase = true) }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            label = { Text(stringResource(R.string.repos_filter)) },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
        )

        when {
            loading -> Centered { CircularProgressIndicator() }

            error != null -> Centered {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(error!!, color = MaterialTheme.colorScheme.error)
                    TextButton(onClick = {
                        scope.launch {
                            loading = true
                            runCatching { app.service.listRepositories() }
                                .onSuccess { repositories = it; error = null }
                                .onFailure { error = it.message }
                            loading = false
                        }
                    }) { Text(stringResource(R.string.common_retry)) }
                }
            }

            filtered.isEmpty() -> Centered { Text(stringResource(R.string.repos_empty)) }

            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(filtered, key = { it.id }) { repository ->
                    RepositoryRow(repository) {
                        onOpen(repository.fullName, repository.defaultBranch, "")
                    }
                    HorizontalDivider()
                }
            }
        }
    }
}

@Composable
private fun RepositoryRow(repository: Repository, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickableRow(onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Folder, null, tint = MaterialTheme.colorScheme.primary)
            Text(
                text = repository.fullName,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(start = 8.dp),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        repository.description?.takeIf { it.isNotBlank() }?.let {
            Text(
                text = it,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
        Text(
            text = buildString {
                append(if (repository.isPrivate) "🔒 " else "")
                append(repository.defaultBranch)
                repository.language?.let { append(" · $it") }
                if (!repository.canPush) append(" · ${'\u0020'}read-only")
            },
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
private fun UploadsTab(app: GitApp, onOpenJob: (String) -> Unit) {
    val jobs by app.uploads.jobs.collectAsState()
    val running by app.uploads.runningJobId.collectAsState()
    val offline by app.uploads.isOffline.collectAsState()

    if (jobs.isEmpty()) {
        Centered { Text(stringResource(R.string.uploads_empty)) }
        return
    }

    LazyColumn(Modifier.fillMaxSize()) {
        if (offline && app.uploads.hasResumableWork) {
            item {
                Text(
                    text = stringResource(R.string.upload_offline),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(16.dp)
                )
            }
        }

        items(jobs, key = { it.id }) { job ->
            JobRow(job = job, isRunning = running == job.id, onClick = { onOpenJob(job.id) })
            HorizontalDivider()
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TextButton(onClick = { app.uploads.resumeAll() }) {
                    Text(stringResource(R.string.upload_resume_all))
                }
                TextButton(onClick = { app.uploads.clearFinished() }) {
                    Text(stringResource(R.string.upload_clear_finished))
                }
            }
        }
    }
}

@Composable
private fun JobRow(job: UploadJob, isRunning: Boolean, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickableRow(onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(job.displayName, style = MaterialTheme.typography.titleMedium, maxLines = 1)
        Text(
            text = "${job.repo.fullName} · ${job.branch}",
            style = MaterialTheme.typography.bodySmall
        )

        if (!job.state.isTerminal) {
            LinearProgressIndicator(
                progress = { job.fraction.toFloat() },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
            )
        }

        Text(
            text = buildString {
                append(stateLabel(job.state))
                if (job.totalFiles > 0) append(" · ${job.settledFiles}/${job.totalFiles}")
                if (job.skippedFiles > 0) append(" · ${job.skippedFiles} unchanged")
                if (isRunning) {
                    job.bytesPerSecond?.let { append(" · ${Formatters.speed(it)}") }
                    job.secondsRemaining?.let { append(" · ${Formatters.duration(it)}") }
                }
            },
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 4.dp)
        )

        job.lastError?.let {
            Text(
                text = it,
                color = MaterialTheme.colorScheme.error,
                style = MaterialTheme.typography.labelSmall,
                maxLines = 3
            )
        }
    }
}

@Composable
private fun SettingsTab(
    app: GitApp,
    onSignOut: () -> Unit,
    onThemeChanged: (String) -> Unit,
    onLanguageChanged: (String) -> Unit
) {
    var user by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        runCatching { app.service.currentUser() }.onSuccess { user = it.displayName }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(stringResource(R.string.settings_account), style = MaterialTheme.typography.titleSmall)
                Text(user ?: "—", style = MaterialTheme.typography.bodyLarge)
                val limit = app.client.rateLimit
                if (limit.limit > 0) {
                    Text(
                        text = stringResource(R.string.settings_rate_limit) +
                            ": ${limit.remaining}/${limit.limit}",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }

        Text(stringResource(R.string.settings_theme), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to R.string.theme_system, "light" to R.string.theme_light, "dark" to R.string.theme_dark)
                .forEach { (value, label) ->
                    OutlinedChoice(
                        text = stringResource(label),
                        selected = app.settings.theme == value,
                        onClick = { onThemeChanged(value) }
                    )
                }
        }

        Text(stringResource(R.string.settings_language), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("system" to R.string.language_system, "en" to R.string.language_en, "ar" to R.string.language_ar)
                .forEach { (value, label) ->
                    OutlinedChoice(
                        text = stringResource(label),
                        selected = app.settings.language == value,
                        onClick = { onLanguageChanged(value) }
                    )
                }
        }

        Button(onClick = onSignOut, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.settings_sign_out))
        }
    }
}

@Composable
private fun OutlinedChoice(text: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(text) }
    } else {
        TextButton(onClick = onClick) { Text(text) }
    }
}

@Composable
fun Centered(content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) { content() }
}

@Composable
fun stateLabel(state: JobState): String = when (state) {
    JobState.QUEUED -> stringResource(R.string.state_queued)
    JobState.SCANNING -> stringResource(R.string.state_scanning)
    JobState.COMPARING -> stringResource(R.string.state_comparing)
    JobState.UPLOADING -> stringResource(R.string.state_uploading)
    JobState.BUILDING_TREE -> stringResource(R.string.state_building_tree)
    JobState.COMMITTING -> stringResource(R.string.state_committing)
    JobState.COMPLETED -> stringResource(R.string.state_completed)
    JobState.PAUSED -> stringResource(R.string.state_paused)
    JobState.FAILED -> stringResource(R.string.state_failed)
    JobState.CANCELLED -> stringResource(R.string.state_cancelled)
}

/** Small helper so rows stay tappable without repeating the modifier chain. */
fun Modifier.clickableRow(onClick: () -> Unit): Modifier = this.clickable(onClick = onClick)
