package com.gitfolderuploader.core.net

/** Every failure the GitHub layer can produce, with a human-readable message. */
sealed class ApiError(message: String, cause: Throwable? = null) : Exception(message, cause) {

    class Unauthorized : ApiError("Token rejected. Sign in again.")
    class Forbidden(val detail: String?) : ApiError(detail ?: "Access denied for this repository.")
    class NotFound : ApiError("Not found.")
    class Conflict(val detail: String?) : ApiError(detail ?: "The remote changed while writing.")
    class Validation(val detail: String?) : ApiError(detail ?: "GitHub rejected the request.")
    class RateLimited(val retryAfterSeconds: Long?) : ApiError("Rate limit reached. Try again shortly.")
    class Server(val status: Int, val detail: String?) : ApiError(detail ?: "GitHub error $status.")
    class Transport(val detail: String) : ApiError(detail)
    class Decoding(val detail: String) : ApiError("Unexpected response: $detail")
    class FileTooLarge(val path: String, val bytes: Long) :
        ApiError("$path is larger than GitHub's 100 MB blob limit.")
    class MissingToken : ApiError("No token stored.")
    class DeviceFlowPending : ApiError("Waiting for approval.")
    class DeviceFlowSlowDown(val seconds: Long) : ApiError("Polling too fast.")
    class DeviceFlowExpired : ApiError("The device code expired.")
    class DeviceFlowDenied : ApiError("The request was denied.")
    class Cancelled : ApiError("Cancelled.")

    /** Whether retrying the same request has any chance of a different result. */
    val isRetryable: Boolean
        get() = this is Transport || this is RateLimited || this is Server
}
