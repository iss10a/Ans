package com.gitfolderuploader.core

import android.util.Log

/**
 * Thin logging facade with fixed tags.
 *
 * Filter picker/upload problems in Logcat with:
 *   adb logcat -s GFU-picker GFU-upload GFU-net
 */
object AppLog {

    private const val PREFIX = "GFU-"

    fun picker(message: String) = Log.i(PREFIX + "picker", message)
    fun pickerError(message: String, error: Throwable? = null) =
        Log.e(PREFIX + "picker", message, error)

    fun upload(message: String) = Log.i(PREFIX + "upload", message)
    fun uploadError(message: String, error: Throwable? = null) =
        Log.e(PREFIX + "upload", message, error)

    fun net(message: String) = Log.i(PREFIX + "net", message)
    fun netError(message: String, error: Throwable? = null) =
        Log.e(PREFIX + "net", message, error)
}
