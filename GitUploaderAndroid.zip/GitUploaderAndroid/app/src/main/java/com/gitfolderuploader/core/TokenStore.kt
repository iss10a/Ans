package com.gitfolderuploader.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKeys

/**
 * Stores the GitHub token.
 *
 * `EncryptedSharedPreferences` is used when the device's keystore cooperates.
 * It is known to fail on a minority of devices with a broken keystore, and a
 * crash on launch would be far worse than the fallback, so a plain
 * app-private preferences file is used if setup throws. App-private storage is
 * still unreadable by other apps on a non-rooted device.
 */
class TokenStore(context: Context) {

    // security-crypto 1.0.0 predates the `MasterKey.Builder` API: it exposes
    // `MasterKeys`, which returns a key *alias* rather than an object, and its
    // `create` takes (fileName, alias, context, ...) in that order. The newer
    // builder only exists in the 1.1.0 alphas, and an alpha dependency is not
    // worth it for storing one token.
    @Suppress("DEPRECATION")
    private val prefs: SharedPreferences = runCatching {
        val alias = MasterKeys.getOrCreate(MasterKeys.AES256_GCM_SPEC)
        EncryptedSharedPreferences.create(
            "gfu_secure",
            alias,
            context,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }.getOrElse {
        AppLog.netError("Encrypted preferences unavailable; falling back to private prefs", it)
        context.getSharedPreferences("gfu_fallback", Context.MODE_PRIVATE)
    }

    var token: String?
        get() = prefs.getString(KEY_TOKEN, null)
        set(value) = prefs.edit().apply {
            if (value == null) remove(KEY_TOKEN) else putString(KEY_TOKEN, value)
        }.apply()

    var oauthClientId: String?
        get() = prefs.getString(KEY_CLIENT_ID, null)
        set(value) = prefs.edit().putString(KEY_CLIENT_ID, value).apply()

    fun clear() = prefs.edit().remove(KEY_TOKEN).apply()

    private companion object {
        const val KEY_TOKEN = "access_token"
        const val KEY_CLIENT_ID = "oauth_client_id"
    }
}
