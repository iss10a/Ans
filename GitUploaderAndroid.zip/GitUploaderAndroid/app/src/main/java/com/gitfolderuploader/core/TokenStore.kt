package com.gitfolderuploader.core

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores the GitHub token.
 *
 * `EncryptedSharedPreferences` is used when the device's keystore cooperates.
 * It is known to fail on a minority of devices with a broken keystore, and a
 * crash on launch would be far worse than the fallback, so a plain
 * app-private preferences file is used if setup throws. App-private storage is
 * still unreadable by other apps on a non-rooted device.
 */
class TokenStore(context: Context) {

    private val prefs: SharedPreferences = runCatching {
        val key = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            context,
            "gfu_secure",
            key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        ) as SharedPreferences
    }.getOrElse {
        AppLog.netError("Encrypted preferences unavailable; falling back to private prefs", it)
        context.getSharedPreferences("gfu_fallback", Context.MODE_PRIVATE)
    }

    var token: String?
        get() = prefs.getString(KEY_TOKEN, null)
        set(value) = prefs.edit().apply {
            if (value == null) remove(KEY_TOKEN) else putString(KEY_TOKEN, value)
        }.apply()

    var oauthClientId: String?
        get() = prefs.getString(KEY_CLIENT_ID, null)
        set(value) = prefs.edit().putString(KEY_CLIENT_ID, value).apply()

    fun clear() = prefs.edit().remove(KEY_TOKEN).apply()

    private companion object {
        const val KEY_TOKEN = "access_token"
        const val KEY_CLIENT_ID = "oauth_client_id"
    }
}
