package com.gitfolderuploader.upload

import android.content.Context
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.domain.model.UploadJob
import kotlinx.serialization.json.Json
import java.io.File

/**
 * Persists jobs as one JSON file each, inside the app's private storage.
 *
 * A file per job means a corrupt record can be dropped without losing the
 * queue, and writing after every state change is cheap enough to do often —
 * which is what allows an interrupted upload to resume from the exact file it
 * stopped on.
 */
class JobStore(context: Context) {

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        prettyPrint = false
    }

    private val directory = File(context.filesDir, "jobs").apply { mkdirs() }

    fun loadAll(): List<UploadJob> {
        val files = directory.listFiles { file -> file.extension == "json" } ?: return emptyList()
        return files.mapNotNull { file ->
            runCatching { json.decodeFromString<UploadJob>(file.readText()) }
                .onFailure {
                    AppLog.uploadError("Dropping unreadable job ${file.name}", it)
                    file.delete()
                }
                .getOrNull()
        }.sortedBy { it.createdAt }
    }

    fun save(job: UploadJob) {
        runCatching {
            File(directory, "${job.id}.json").writeText(json.encodeToString(UploadJob.serializer(), job))
        }.onFailure { AppLog.uploadError("Could not persist job ${job.id}", it) }
    }

    fun delete(id: String) {
        File(directory, "$id.json").delete()
    }
}
