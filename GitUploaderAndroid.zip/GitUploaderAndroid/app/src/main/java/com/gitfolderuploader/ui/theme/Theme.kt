package com.gitfolderuploader.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val BrandLight = lightColorScheme(
    primary = Color(0xFF2F6FEB),
    secondary = Color(0xFF4A5568),
    tertiary = Color(0xFF238636)
)

private val BrandDark = darkColorScheme(
    primary = Color(0xFF6C9BFF),
    secondary = Color(0xFFA0AEC0),
    tertiary = Color(0xFF3FB950)
)

/**
 * @param themeSetting "system", "light" or "dark".
 */
@Composable
fun GitUploaderTheme(
    themeSetting: String,
    dynamicColor: Boolean = true,
    content: @Composable () -> Unit
) {
    val dark = when (themeSetting) {
        "light" -> false
        "dark" -> true
        else -> isSystemInDarkTheme()
    }

    val colors = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        dark -> BrandDark
        else -> BrandLight
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = colors.background.toArgb()
            WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark
        }
    }

    MaterialTheme(colorScheme = colors, content = content)
}
