package com.gitfolderuploader.data.remote

import android.util.Base64
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.core.net.ApiError
import com.gitfolderuploader.core.net.GitHubClient
import com.gitfolderuploader.data.dto.BlobCreationDto
import com.gitfolderuploader.data.dto.BranchDto
import com.gitfolderuploader.data.dto.CodeSearchDto
import com.gitfolderuploader.data.dto.CommitDto
import com.gitfolderuploader.data.dto.ContentEntryDto
import com.gitfolderuploader.data.dto.DeviceCodeDto
import com.gitfolderuploader.data.dto.DeviceTokenDto
import com.gitfolderuploader.data.dto.ReferenceDto
import com.gitfolderuploader.data.dto.RepositoryDto
import com.gitfolderuploader.data.dto.RepositorySearchDto
import com.gitfolderuploader.data.dto.TreeDto
import com.gitfolderuploader.data.dto.UserDto
import com.gitfolderuploader.domain.model.Branch
import com.gitfolderuploader.domain.model.DeviceCodeSession
import com.gitfolderuploader.domain.model.GitCommitRef
import com.gitfolderuploader.domain.model.GitHubUser
import com.gitfolderuploader.domain.model.GitTree
import com.gitfolderuploader.domain.model.RepoItem
import com.gitfolderuploader.domain.model.RepoRef
import com.gitfolderuploader.domain.model.Repository
import com.gitfolderuploader.domain.model.TreeEntry
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.jsonArray
import java.net.URLEncoder

/**
 * Every GitHub call the app makes.
 *
 * Uploads go through the **Git Data API** (blob → tree → commit → ref) rather
 * than the Contents API, because the Contents API creates one commit per file —
 * unusable for a folder holding thousands of them.
 */
class GitHubService(private val client: GitHubClient) {

    private val api = "https://api.github.com"
    private val web = "https://github.com"

    private fun base(ref: RepoRef) = "$api/repos/${ref.owner}/${ref.name}"

    private fun encode(value: String) = URLEncoder.encode(value, "UTF-8").replace("+", "%20")

    /** Encodes a repository path segment by segment; slashes must survive. */
    private fun encodePath(path: String) =
        path.split("/").filter { it.isNotEmpty() }.joinToString("/") { encode(it) }

    // ---------------------------------------------------------------- Auth

    suspend fun currentUser(): GitHubUser {
        val dto = client.decode<UserDto>(client.request("$api/user").body)
        return GitHubUser(dto.login, dto.name, dto.avatarUrl, dto.publicRepos, dto.privateRepos)
    }

    /** Starts the OAuth device flow. Only a client ID is needed — no secret. */
    suspend fun startDeviceFlow(clientId: String): DeviceCodeSession {
        val body = buildJsonObject {
            put("client_id", JsonPrimitive(clientId))
            put("scope", JsonPrimitive("repo read:user"))
        }.toString()

        val response = client.request(
            url = "$web/login/device/code",
            method = "POST",
            body = body,
            accept = "application/json"
        )
        val dto = client.decode<DeviceCodeDto>(response.body)
        return DeviceCodeSession(
            deviceCode = dto.deviceCode,
            userCode = dto.userCode,
            verificationUri = dto.verificationUri,
            intervalSeconds = dto.interval,
            expiresInSeconds = dto.expiresIn
        )
    }

    /** One poll of the device-flow token endpoint. */
    suspend fun pollDeviceToken(clientId: String, deviceCode: String): String {
        val body = buildJsonObject {
            put("client_id", JsonPrimitive(clientId))
            put("device_code", JsonPrimitive(deviceCode))
            put("grant_type", JsonPrimitive("urn:ietf:params:oauth:grant-type:device_code"))
        }.toString()

        val response = client.request(
            url = "$web/login/oauth/access_token",
            method = "POST",
            body = body,
            accept = "application/json"
        )
        val dto = client.decode<DeviceTokenDto>(response.body)
        dto.accessToken?.let { return it }

        throw when (dto.error) {
            "authorization_pending" -> ApiError.DeviceFlowPending()
            "slow_down" -> ApiError.DeviceFlowSlowDown(dto.interval ?: 5)
            "expired_token" -> ApiError.DeviceFlowExpired()
            "access_denied" -> ApiError.DeviceFlowDenied()
            else -> ApiError.Validation(dto.error)
        }
    }

    // -------------------------------------------------------- Repositories

    suspend fun listRepositories(): List<Repository> {
        val pages = client.requestAllPages(
            "$api/user/repos?per_page=100&sort=updated&affiliation=owner,collaborator,organization_member"
        )
        return pages.flatMap { page ->
            client.decode<List<RepositoryDto>>(page).map { it.toDomain() }
        }
    }

    suspend fun searchRepositories(query: String, page: Int = 1): List<Repository> {
        if (query.isBlank()) return emptyList()
        val url = "$api/search/repositories?q=${encode(query)}&per_page=30&page=$page"
        return client.decode<RepositorySearchDto>(client.request(url).body).items.map { it.toDomain() }
    }

    suspend fun createRepository(
        name: String,
        description: String?,
        isPrivate: Boolean,
        autoInit: Boolean
    ): Repository {
        val body = buildJsonObject {
            put("name", JsonPrimitive(name))
            if (!description.isNullOrBlank()) put("description", JsonPrimitive(description))
            put("private", JsonPrimitive(isPrivate))
            put("auto_init", JsonPrimitive(autoInit))
        }.toString()

        val response = client.request("$api/user/repos", "POST", body)
        return client.decode<RepositoryDto>(response.body).toDomain()
    }

    suspend fun repository(ref: RepoRef): Repository =
        client.decode<RepositoryDto>(client.request(base(ref)).body).toDomain()

    // -------------------------------------------------------------- Content

    suspend fun listContents(ref: RepoRef, path: String, branch: String): List<RepoItem> {
        val url = buildString {
            append(base(ref)).append("/contents/").append(encodePath(path))
            append("?ref=").append(encode(branch))
        }
        val body = client.request(url).body
        val element = client.parse(body)

        // A file path returns an object; a directory returns an array.
        val entries: List<ContentEntryDto> = if (element is JsonArray) {
            client.decode<List<ContentEntryDto>>(body)
        } else {
            listOf(client.decode<ContentEntryDto>(body))
        }

        return entries
            .map {
                RepoItem(
                    name = it.name,
                    path = it.path,
                    sha = it.sha,
                    size = it.size,
                    isDirectory = it.type == "dir",
                    downloadUrl = it.downloadUrl
                )
            }
            .sortedWith(compareByDescending<RepoItem> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    /** Raw bytes of one file, used by the preview screen. */
    suspend fun readFile(ref: RepoRef, path: String, branch: String): ByteArray {
        val url = "${base(ref)}/contents/${encodePath(path)}?ref=${encode(branch)}"
        val dto = client.decode<ContentEntryDto>(client.request(url).body)
        val content = dto.content ?: return ByteArray(0)
        val cleaned = content.replace("\n", "").replace("\r", "")
        return runCatching { Base64.decode(cleaned, Base64.DEFAULT) }.getOrElse { ByteArray(0) }
    }

    // ------------------------------------------------------------- Branches

    suspend fun listBranches(ref: RepoRef): List<Branch> {
        val pages = client.requestAllPages("${base(ref)}/branches?per_page=100")
        return pages.flatMap { page ->
            client.decode<List<BranchDto>>(page).map {
                Branch(it.name, it.commit.sha, it.isProtected)
            }
        }
    }

    // ------------------------------------------------------------ Git data

    suspend fun reference(ref: RepoRef, branch: String): String {
        val url = "${base(ref)}/git/ref/heads/${encodePath(branch)}"
        return client.decode<ReferenceDto>(client.request(url).body).target.sha
    }

    suspend fun commit(ref: RepoRef, sha: String): GitCommitRef {
        val dto = client.decode<CommitDto>(client.request("${base(ref)}/git/commits/$sha").body)
        return GitCommitRef(dto.sha, dto.tree.sha, dto.message)
    }

    suspend fun tree(ref: RepoRef, sha: String, recursive: Boolean): GitTree {
        val url = "${base(ref)}/git/trees/$sha" + if (recursive) "?recursive=1" else ""
        val dto = client.decode<TreeDto>(client.request(url).body)
        return GitTree(
            sha = dto.sha,
            entries = dto.tree.map { TreeEntry(it.path, it.mode, it.type, it.sha, it.size) },
            truncated = dto.truncated
        )
    }

    /**
     * Uploads file bytes as a blob.
     *
     * [onProgress] receives a 0..1 fraction as the request body is written,
     * which is what drives the per-file progress bar.
     */
    suspend fun createBlob(
        ref: RepoRef,
        bytes: ByteArray,
        onProgress: ((Double) -> Unit)? = null
    ): String {
        if (bytes.size > MAX_BLOB_BYTES) {
            throw ApiError.FileTooLarge(ref.fullName, bytes.size.toLong())
        }
        val body = buildJsonObject {
            put("content", JsonPrimitive(Base64.encodeToString(bytes, Base64.NO_WRAP)))
            put("encoding", JsonPrimitive("base64"))
        }.toString()

        val response = client.request("${base(ref)}/git/blobs", "POST", body, onProgress = onProgress)
        return client.decode<BlobCreationDto>(response.body).sha
    }

    /** Creates a tree, optionally layered on top of [baseTreeSha]. */
    suspend fun createTree(ref: RepoRef, baseTreeSha: String?, entries: List<TreeEntry>): String {
        val body = buildJsonObject {
            if (baseTreeSha != null) put("base_tree", JsonPrimitive(baseTreeSha))
            put("tree", buildJsonArray {
                entries.forEach { entry ->
                    add(buildJsonObject {
                        put("path", JsonPrimitive(entry.path))
                        put("mode", JsonPrimitive(entry.mode))
                        put("type", JsonPrimitive(entry.type))
                        // A null sha deletes the path; JsonNull is required here.
                        if (entry.sha == null) put("sha", JsonNull)
                        else put("sha", JsonPrimitive(entry.sha))
                    })
                }
            })
        }.toString()

        val response = client.request("${base(ref)}/git/trees", "POST", body)
        return (client.parse(response.body) as JsonObject)["sha"].toString().trim('"')
    }

    suspend fun createCommit(
        ref: RepoRef,
        message: String,
        treeSha: String,
        parents: List<String>
    ): String {
        val body = buildJsonObject {
            put("message", JsonPrimitive(message))
            put("tree", JsonPrimitive(treeSha))
            put("parents", buildJsonArray { parents.forEach { add(JsonPrimitive(it)) } })
        }.toString()

        val response = client.request("${base(ref)}/git/commits", "POST", body)
        return (client.parse(response.body) as JsonObject)["sha"].toString().trim('"')
    }

    suspend fun createBranch(ref: RepoRef, name: String, fromSha: String) {
        val body = buildJsonObject {
            put("ref", JsonPrimitive("refs/heads/$name"))
            put("sha", JsonPrimitive(fromSha))
        }.toString()
        client.request("${base(ref)}/git/refs", "POST", body)
    }

    suspend fun updateBranch(ref: RepoRef, name: String, toSha: String, force: Boolean) {
        val body = buildJsonObject {
            put("sha", JsonPrimitive(toSha))
            put("force", JsonPrimitive(force))
        }.toString()
        client.request("${base(ref)}/git/refs/heads/${encodePath(name)}", "PATCH", body)
    }

    // --------------------------------------------------------------- Search

    /** Filename search inside one repository, backed by the recursive tree. */
    suspend fun searchFiles(ref: RepoRef, branch: String, query: String): List<RepoItem> {
        if (query.isBlank()) return emptyList()
        val head = reference(ref, branch)
        val treeSha = commit(ref, head).treeSha
        val tree = tree(ref, treeSha, recursive = true)
        val needle = query.lowercase()

        return tree.entries
            .filter { it.type == "blob" && it.path.lowercase().contains(needle) }
            .take(200)
            .map {
                RepoItem(
                    name = it.path.substringAfterLast('/'),
                    path = it.path,
                    sha = it.sha ?: "",
                    size = it.size,
                    isDirectory = false
                )
            }
            .sortedBy { it.path.length }
    }

    /** Content search through GitHub's code index. */
    suspend fun searchCode(ref: RepoRef, query: String): List<RepoItem> {
        if (query.isBlank()) return emptyList()
        val url = "$api/search/code?q=${encode("$query repo:${ref.fullName}")}&per_page=50"
        return client.decode<CodeSearchDto>(client.request(url).body).items.map {
            RepoItem(it.name, it.path, it.sha, 0, false)
        }
    }

    private fun RepositoryDto.toDomain() = Repository(
        id = id,
        name = name,
        fullName = fullName,
        owner = owner.login,
        description = description,
        isPrivate = isPrivate,
        defaultBranch = defaultBranch,
        canPush = permissions?.push ?: true,
        updatedAt = updatedAt,
        language = language,
        stars = stars
    )

    companion object {
        /** GitHub refuses blobs above 100 MB. */
        const val MAX_BLOB_BYTES = 100L * 1024 * 1024
    }
}
