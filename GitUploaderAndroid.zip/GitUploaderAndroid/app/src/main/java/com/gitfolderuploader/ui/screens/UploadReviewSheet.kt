package com.gitfolderuploader.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gitfolderuploader.GitApp
import com.gitfolderuploader.R
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.core.Formatters
import com.gitfolderuploader.domain.model.ConflictPolicy
import com.gitfolderuploader.domain.model.RepoRef
import com.gitfolderuploader.domain.model.UploadFile
import com.gitfolderuploader.domain.model.UploadJob
import com.gitfolderuploader.domain.model.UploadSource
import com.gitfolderuploader.upload.SafScanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The step between picking and uploading.
 *
 * Shows the file count, the total size and every path, and lets individual
 * files be excluded before a single byte moves.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadReviewSheet(
    app: GitApp,
    sources: List<UploadSource>,
    repo: RepoRef,
    branch: String,
    currentPath: String,
    onDismiss: () -> Unit,
    onQueued: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = androidx.compose.ui.platform.LocalContext.current

    var scanning by remember { mutableStateOf(true) }
    var files by remember { mutableStateOf<List<UploadFile>>(emptyList()) }
    var excluded by remember { mutableStateOf<Set<String>>(emptySet()) }
    var warnings by remember { mutableStateOf<List<String>>(emptyList()) }
    var showAll by remember { mutableStateOf(false) }

    val singleFolder = sources.size == 1 && sources[0].isFolder
    // Default off. Nesting a project one level deep breaks every tool that
    // only ever looks at the repository root — Codemagic reads codemagic.yaml
    // there, Flutter needs pubspec.yaml there, GitHub Actions reads
    // .github/workflows there. Pushing from a computer lands files at the root,
    // and this default matches that.
    var placeInsideFolder by remember { mutableStateOf(false) }
    var customPath by remember { mutableStateOf("") }
    var commitMessage by remember { mutableStateOf("") }
    var policy by remember { mutableStateOf(ConflictPolicy.REPLACE) }

    val destination = remember(placeInsideFolder, customPath, currentPath, sources) {
        val custom = customPath.trim('/', ' ')
        when {
            custom.isNotEmpty() -> custom
            singleFolder && placeInsideFolder ->
                listOf(currentPath.trim('/', ' '), sources[0].displayName)
                    .filter { it.isNotEmpty() }
                    .joinToString("/")
            else -> currentPath.trim('/', ' ')
        }
    }

    val included = files.filterNot { it.relativePath in excluded }
    val includedBytes = included.sumOf { it.size }

    LaunchedEffect(sources) {
        scanning = true
        val result = withContext(Dispatchers.IO) {
            SafScanner.scan(context, sources, prefixWithSourceName = sources.size > 1)
        }
        files = result.files
        warnings = buildList {
            if (result.oversized.isNotEmpty()) {
                add(context.getString(R.string.upload_warning_oversized) + " " +
                    result.oversized.take(4).joinToString(", "))
            }
            if (result.unreadable.isNotEmpty()) {
                add(context.getString(R.string.upload_warning_unreadable) + " " +
                    result.unreadable.take(4).joinToString(", "))
            }
        }
        if (commitMessage.isBlank()) {
            val name = if (sources.size == 1) sources[0].displayName else "${sources.size} items"
            commitMessage = context.getString(R.string.upload_default_message, name)
        }
        AppLog.picker("Review ready: ${files.size} file(s), ${Formatters.size(result.totalBytes)}")
        scanning = false
    }

    // Files that only work at the repository root, warned about when the
    // destination would bury them in a subfolder.
    val rootAnchored = remember(included, destination) {
        if (destination.isEmpty()) emptyList()
        else included.map { it.relativePath }
            .filter { !it.contains('/') && it in ROOT_ANCHORED_NAMES }
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheetState) {
        Column(
            modifier = Modifier.padding(horizontal = 20.dp).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = stringResource(R.string.upload_review_title),
                style = MaterialTheme.typography.headlineSmall
            )

            if (scanning) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    CircularProgressIndicator()
                    Text(stringResource(R.string.upload_scanning))
                }
            } else {
                Text(
                    text = stringResource(
                        R.string.upload_summary,
                        included.size,
                        files.size,
                        Formatters.size(includedBytes)
                    ),
                    style = MaterialTheme.typography.bodyMedium
                )
            }

            warnings.forEach {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
            }

            Text("${repo.fullName} · $branch", style = MaterialTheme.typography.labelMedium)

            if (singleFolder) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = stringResource(R.string.upload_place_inside, sources[0].displayName),
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = placeInsideFolder,
                        onCheckedChange = { placeInsideFolder = it },
                        enabled = customPath.isBlank()
                    )
                }
            }

            OutlinedTextField(
                value = customPath,
                onValueChange = { customPath = it },
                label = { Text(stringResource(R.string.upload_custom_path)) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )

            Text(
                text = if (destination.isEmpty()) {
                    stringResource(R.string.upload_destination_root)
                } else {
                    "/$destination"
                },
                fontFamily = FontFamily.Monospace,
                style = MaterialTheme.typography.labelMedium
            )

            if (rootAnchored.isNotEmpty()) {
                Text(
                    text = stringResource(
                        R.string.upload_root_warning,
                        rootAnchored.take(3).joinToString(", ")
                    ),
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.labelSmall
                )
            }

            OutlinedTextField(
                value = commitMessage,
                onValueChange = { commitMessage = it },
                label = { Text(stringResource(R.string.upload_commit_message)) },
                modifier = Modifier.fillMaxWidth()
            )

            Text(stringResource(R.string.conflict_policy), style = MaterialTheme.typography.labelLarge)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ConflictPolicy.entries.forEach { option ->
                    if (option == policy) {
                        Button(onClick = { policy = option }) { Text(policyLabel(option)) }
                    } else {
                        TextButton(onClick = { policy = option }) { Text(policyLabel(option)) }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(
                    onClick = { excluded = emptySet() },
                    enabled = excluded.isNotEmpty()
                ) { Text(stringResource(R.string.common_select_all)) }

                TextButton(
                    onClick = { excluded = files.map { it.relativePath }.toSet() },
                    enabled = included.isNotEmpty()
                ) { Text(stringResource(R.string.common_deselect_all)) }
            }

            val visible = if (showAll) files else files.take(150)
            LazyColumn(modifier = Modifier.fillMaxWidth().heightIn(max = 280.dp)) {
                items(visible, key = { it.relativePath }) { file ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = file.relativePath !in excluded,
                            onCheckedChange = { checked ->
                                excluded = if (checked) {
                                    excluded - file.relativePath
                                } else {
                                    excluded + file.relativePath
                                }
                            }
                        )
                        Column(Modifier.weight(1f)) {
                            Text(
                                text = file.relativePath,
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = Formatters.size(file.size),
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
                if (!showAll && files.size > 150) {
                    item {
                        TextButton(onClick = { showAll = true }) {
                            Text(stringResource(R.string.upload_show_all, files.size))
                        }
                    }
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                TextButton(onClick = onDismiss) { Text(stringResource(R.string.common_cancel)) }
                Button(
                    onClick = {
                        val job = UploadJob(
                            repoOwner = repo.owner,
                            repoName = repo.name,
                            branch = branch,
                            remoteRoot = destination,
                            commitMessage = commitMessage.ifBlank { "Upload from Android" },
                            sources = sources,
                            displayName = if (sources.size == 1) {
                                sources[0].displayName
                            } else {
                                "${sources.size} items"
                            },
                            conflictPolicy = policy,
                            files = included
                        )
                        app.uploads.enqueue(job)
                        onQueued()
                    },
                    enabled = !scanning && included.isNotEmpty()
                ) { Text(stringResource(R.string.upload_start)) }
            }
        }
    }
}

@Composable
private fun policyLabel(policy: ConflictPolicy): String = when (policy) {
    ConflictPolicy.REPLACE -> stringResource(R.string.conflict_replace)
    ConflictPolicy.SKIP -> stringResource(R.string.conflict_skip)
    ConflictPolicy.RENAME -> stringResource(R.string.conflict_rename)
}

private val ROOT_ANCHORED_NAMES = setOf(
    "codemagic.yaml", "codemagic.yml",
    "pubspec.yaml", "pubspec.yml",
    "package.json", "Package.swift", "Cargo.toml",
    "Gemfile", "requirements.txt", "pyproject.toml",
    "Dockerfile", "docker-compose.yml",
    "build.gradle", "build.gradle.kts", "settings.gradle", "settings.gradle.kts",
    "pom.xml", ".gitignore", "analysis_options.yaml"
)
