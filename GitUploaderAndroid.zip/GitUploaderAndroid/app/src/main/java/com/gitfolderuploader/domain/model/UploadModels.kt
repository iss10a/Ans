package com.gitfolderuploader.domain.model

import kotlinx.serialization.Serializable
import java.util.UUID

/**
 * One item the user picked.
 *
 * A folder is stored as its SAF tree URI. Because the app calls
 * `takePersistableUriPermission`, that URI keeps working after the process dies
 * and after a reboot — which is what makes a paused job genuinely resumable
 * without copying anything.
 */
@Serializable
data class UploadSource(
    val id: String = UUID.randomUUID().toString(),
    val uri: String,
    val displayName: String,
    val isFolder: Boolean
)

/** What to do when the destination already holds a *different* file. */
@Serializable
enum class ConflictPolicy { REPLACE, SKIP, RENAME }

@Serializable
enum class FileState { PENDING, UPLOADING, UPLOADED, SKIPPED, FAILED }

@Serializable
data class UploadFile(
    /** Path relative to the destination, hierarchy preserved. */
    val relativePath: String,
    /** SAF document URI of the local file. */
    val uri: String,
    val size: Long,
    /** Locally computed Git blob SHA-1. */
    val gitSha: String,
    var remoteBlobSha: String? = null,
    var state: FileState = FileState.PENDING,
    var errorMessage: String? = null,
    var attempts: Int = 0,
    var bytesSent: Long = 0,
    /** Set when the conflict policy is RENAME. */
    var renamedRelativePath: String? = null,
    var hasConflict: Boolean = false
) {
    val name: String get() = relativePath.substringAfterLast('/')

    fun remotePath(root: String): String {
        val relative = renamedRelativePath ?: relativePath
        val cleanRoot = root.trim('/', ' ')
        return if (cleanRoot.isEmpty()) relative else "$cleanRoot/$relative"
    }

    val fraction: Double
        get() = when (state) {
            FileState.UPLOADED, FileState.SKIPPED -> 1.0
            FileState.PENDING, FileState.FAILED -> 0.0
            FileState.UPLOADING -> if (size <= 0) 0.0 else (bytesSent.toDouble() / size).coerceIn(0.0, 1.0)
        }
}

@Serializable
enum class JobState {
    QUEUED, SCANNING, COMPARING, UPLOADING, BUILDING_TREE, COMMITTING,
    COMPLETED, PAUSED, FAILED, CANCELLED;

    val isTerminal: Boolean get() = this == COMPLETED || this == FAILED || this == CANCELLED
    val isActive: Boolean get() = this == SCANNING || this == COMPARING ||
        this == UPLOADING || this == BUILDING_TREE || this == COMMITTING
    val isResumable: Boolean get() = this == PAUSED || this == FAILED || this == QUEUED
}

@Serializable
data class UploadJob(
    val id: String = UUID.randomUUID().toString(),
    val repoOwner: String,
    val repoName: String,
    val branch: String,
    /** Destination inside the repository; empty means the repository root. */
    val remoteRoot: String,
    val commitMessage: String,
    val sources: List<UploadSource>,
    val displayName: String,
    val conflictPolicy: ConflictPolicy = ConflictPolicy.REPLACE,
    var files: List<UploadFile> = emptyList(),
    var state: JobState = JobState.QUEUED,
    var lastError: String? = null,
    var resultCommitSha: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    var updatedAt: Long = System.currentTimeMillis(),
    var transferStartedAt: Long? = null,
    var bytesSentBeforeRun: Long = 0
) {
    val repo: RepoRef get() = RepoRef(repoOwner, repoName)

    val totalFiles: Int get() = files.size
    val settledFiles: Int get() = files.count {
        it.state == FileState.UPLOADED || it.state == FileState.SKIPPED
    }
    val skippedFiles: Int get() = files.count { it.state == FileState.SKIPPED }
    val failedFiles: Int get() = files.count { it.state == FileState.FAILED }
    val conflictCount: Int get() = files.count { it.hasConflict }

    /** Total size of everything that still has to travel. */
    val transferableBytes: Long
        get() = files.filter { it.state != FileState.SKIPPED }.sumOf { it.size }

    /** Bytes on the wire so far, including files still in flight. */
    val transferredBytes: Long
        get() = files.sumOf {
            when (it.state) {
                FileState.UPLOADED -> it.size
                FileState.UPLOADING -> minOf(it.bytesSent, it.size)
                else -> 0L
            }
        }

    val fraction: Double
        get() {
            if (totalFiles == 0) return if (state.isTerminal) 1.0 else 0.0
            val transferable = transferableBytes
            if (transferable <= 0) return settledFiles.toDouble() / totalFiles
            return (transferredBytes.toDouble() / transferable).coerceIn(0.0, 1.0)
        }

    val bytesPerSecond: Double?
        get() {
            val started = transferStartedAt ?: return null
            val elapsed = (System.currentTimeMillis() - started) / 1000.0
            if (elapsed <= 1.0) return null
            val moved = (transferredBytes - bytesSentBeforeRun).toDouble()
            return if (moved > 0) moved / elapsed else null
        }

    val secondsRemaining: Double?
        get() {
            val speed = bytesPerSecond ?: return null
            val remaining = (transferableBytes - transferredBytes).toDouble()
            return if (speed > 0 && remaining > 0) remaining / speed else null
        }
}
