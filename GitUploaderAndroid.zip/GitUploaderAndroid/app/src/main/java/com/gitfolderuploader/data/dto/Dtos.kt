package com.gitfolderuploader.data.dto

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class UserDto(
    val login: String,
    val name: String? = null,
    @SerialName("avatar_url") val avatarUrl: String? = null,
    @SerialName("public_repos") val publicRepos: Int = 0,
    @SerialName("total_private_repos") val privateRepos: Int = 0
)

@Serializable
data class OwnerDto(val login: String)

@Serializable
data class PermissionsDto(val push: Boolean = true, val admin: Boolean = false)

@Serializable
data class RepositoryDto(
    val id: Long,
    val name: String,
    @SerialName("full_name") val fullName: String,
    val owner: OwnerDto,
    val description: String? = null,
    @SerialName("private") val isPrivate: Boolean = false,
    @SerialName("default_branch") val defaultBranch: String = "main",
    val permissions: PermissionsDto? = null,
    @SerialName("updated_at") val updatedAt: String? = null,
    val language: String? = null,
    @SerialName("stargazers_count") val stars: Int = 0
)

@Serializable
data class RepositorySearchDto(
    @SerialName("total_count") val totalCount: Int = 0,
    val items: List<RepositoryDto> = emptyList()
)

@Serializable
data class CommitShaDto(val sha: String)

@Serializable
data class BranchDto(
    val name: String,
    val commit: CommitShaDto,
    @SerialName("protected") val isProtected: Boolean = false
)

@Serializable
data class ContentEntryDto(
    val name: String,
    val path: String,
    val sha: String,
    val size: Long = 0,
    val type: String,
    @SerialName("download_url") val downloadUrl: String? = null,
    val content: String? = null,
    val encoding: String? = null
)

@Serializable
data class RefObjectDto(val sha: String, val type: String = "commit")

@Serializable
data class ReferenceDto(val ref: String, @SerialName("object") val target: RefObjectDto)

@Serializable
data class TreeRefDto(val sha: String)

@Serializable
data class CommitDto(
    val sha: String,
    val message: String = "",
    val tree: TreeRefDto
)

@Serializable
data class TreeEntryDto(
    val path: String,
    val mode: String,
    val type: String,
    val sha: String? = null,
    val size: Long = 0
)

@Serializable
data class TreeDto(
    val sha: String,
    val tree: List<TreeEntryDto> = emptyList(),
    val truncated: Boolean = false
)

@Serializable
data class BlobCreationDto(val sha: String)

@Serializable
data class CodeSearchItemDto(
    val name: String,
    val path: String,
    val sha: String
)

@Serializable
data class CodeSearchDto(
    @SerialName("total_count") val totalCount: Int = 0,
    val items: List<CodeSearchItemDto> = emptyList()
)

@Serializable
data class DeviceCodeDto(
    @SerialName("device_code") val deviceCode: String,
    @SerialName("user_code") val userCode: String,
    @SerialName("verification_uri") val verificationUri: String,
    val interval: Long = 5,
    @SerialName("expires_in") val expiresIn: Long = 900
)

@Serializable
data class DeviceTokenDto(
    @SerialName("access_token") val accessToken: String? = null,
    val error: String? = null,
    val interval: Long? = null
)
