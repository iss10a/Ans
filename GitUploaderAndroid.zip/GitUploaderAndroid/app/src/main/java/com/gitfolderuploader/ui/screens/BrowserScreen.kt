package com.gitfolderuploader.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.draganddrop.dragAndDropTarget
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draganddrop.DragAndDropEvent
import androidx.compose.ui.draganddrop.DragAndDropTarget
import androidx.compose.ui.draganddrop.toAndroidDragEvent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gitfolderuploader.GitApp
import com.gitfolderuploader.R
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.domain.model.RepoItem
import com.gitfolderuploader.domain.model.RepoRef
import com.gitfolderuploader.domain.model.UploadSource
import com.gitfolderuploader.upload.SafScanner
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun BrowserScreen(
    app: GitApp,
    fullName: String,
    branch: String,
    path: String,
    onOpenFolder: (String, String, String) -> Unit,
    onBack: () -> Unit,
    onOpenQueue: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbar = remember { SnackbarHostState() }
    val ref = remember(fullName) { RepoRef.parse(fullName) }

    var items by remember { mutableStateOf<List<RepoItem>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var staged by remember { mutableStateOf<List<UploadSource>?>(null) }

    fun stage(sources: List<UploadSource>) {
        if (sources.isEmpty()) {
            scope.launch { snackbar.showSnackbar(context.getString(R.string.upload_nothing_usable)) }
            return
        }
        AppLog.picker("Staging ${sources.size} source(s)")
        staged = sources
    }

    // ---- Folder picker -----------------------------------------------------
    // ACTION_OPEN_DOCUMENT_TREE is the only intent that returns a *folder*.
    // The tree URI it produces, once persisted, keeps working after a reboot.
    val folderPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri == null) {
            AppLog.picker("Folder picker cancelled")
            return@rememberLauncherForActivityResult
        }
        val source = SafScanner.describe(context, uri, isTree = true)
        stage(listOfNotNull(source))
    }

    // ---- File picker (multiple) -------------------------------------------
    val filePicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        val sources = uris.mapNotNull { SafScanner.describe(context, it, isTree = false) }
        stage(sources)
    }

    LaunchedEffect(fullName, branch, path) {
        if (ref == null) {
            error = "Invalid repository"
            loading = false
            return@LaunchedEffect
        }
        loading = true
        runCatching { app.service.listContents(ref, path, branch) }
            .onSuccess { items = it; error = null }
            .onFailure { error = it.message }
        loading = false
    }

    // ---- Drag & drop -------------------------------------------------------
    // Android delivers dragged items as ClipData holding content URIs, and a
    // folder dragged from Files arrives as a tree URI. Both are handled.
    val dropTarget = remember {
        object : DragAndDropTarget {
            override fun onDrop(event: DragAndDropEvent): Boolean {
                val clip = event.toAndroidDragEvent().clipData ?: return false
                val sources = mutableListOf<UploadSource>()
                for (index in 0 until clip.itemCount) {
                    val uri = clip.getItemAt(index).uri ?: continue
                    val isTree = runCatching {
                        android.provider.DocumentsContract.isTreeUri(uri)
                    }.getOrDefault(false)
                    SafScanner.describe(context, uri, isTree)?.let { sources += it }
                }
                AppLog.picker("Drop produced ${sources.size} source(s)")
                stage(sources)
                return sources.isNotEmpty()
            }
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(fullName, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            text = if (path.isEmpty()) "/ · $branch" else "/$path · $branch",
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                },
                actions = {
                    IconButton(onClick = { menuOpen = true }) {
                        Icon(Icons.Default.CloudUpload, stringResource(R.string.upload_title))
                    }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.upload_pick_files)) },
                            onClick = {
                                menuOpen = false
                                filePicker.launch(arrayOf("*/*"))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.upload_pick_folder)) },
                            onClick = {
                                menuOpen = false
                                folderPicker.launch(null)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.upload_paste)) },
                            onClick = {
                                menuOpen = false
                                stage(sourcesFromClipboard(context))
                            }
                        )
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.upload_open_queue)) },
                            onClick = { menuOpen = false; onOpenQueue() }
                        )
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                // Accept every drag; `onDrop` reports false when the payload
                // holds no content URI, which is the reliable test.
                .dragAndDropTarget(
                    shouldStartDragAndDrop = { true },
                    target = dropTarget
                )
        ) {
            when {
                loading -> Centered { CircularProgressIndicator() }

                error != null -> Centered {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(error!!, color = MaterialTheme.colorScheme.error)
                    }
                }

                items.isEmpty() -> Centered {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(stringResource(R.string.browser_empty))
                        TextButton(onClick = { folderPicker.launch(null) }) {
                            Text(stringResource(R.string.upload_pick_folder))
                        }
                    }
                }

                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(items, key = { it.path }) { item ->
                        ItemRow(item) {
                            if (item.isDirectory) onOpenFolder(fullName, branch, item.path)
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
    }

    val stagedSources = staged
    if (stagedSources != null && ref != null) {
        UploadReviewSheet(
            app = app,
            sources = stagedSources,
            repo = ref,
            branch = branch,
            currentPath = path,
            onDismiss = { staged = null },
            onQueued = {
                staged = null
                scope.launch { snackbar.showSnackbar(context.getString(R.string.upload_queued)) }
            }
        )
    }
}

@Composable
private fun ItemRow(item: RepoItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickableRow(onClick)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (item.isDirectory) Icons.Default.Folder else Icons.Default.Description,
            contentDescription = null,
            tint = if (item.isDirectory) {
                MaterialTheme.colorScheme.primary
            } else {
                MaterialTheme.colorScheme.onSurfaceVariant
            }
        )
        Column(Modifier.padding(start = 12.dp)) {
            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (!item.isDirectory) {
                Text(
                    text = com.gitfolderuploader.core.Formatters.size(item.size),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
    }
}

/**
 * Reads whatever the user copied in the Files app.
 *
 * Android puts content URIs on the clipboard, so a copied folder arrives as a
 * tree URI and is handled exactly like one chosen through the picker.
 */
private fun sourcesFromClipboard(context: Context): List<UploadSource> {
    val manager = context.getSystemService(Context.CLIPBOARD_SERVICE)
        as? android.content.ClipboardManager ?: return emptyList()
    val clip = manager.primaryClip ?: return emptyList()

    val sources = mutableListOf<UploadSource>()
    for (index in 0 until clip.itemCount) {
        val uri: Uri = clip.getItemAt(index).uri ?: continue
        val isTree = runCatching {
            android.provider.DocumentsContract.isTreeUri(uri)
        }.getOrDefault(false)
        SafScanner.describe(context, uri, isTree)?.let { sources += it }
    }
    AppLog.picker("Clipboard produced ${sources.size} source(s)")
    return sources
}
