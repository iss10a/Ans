package com.gitfolderuploader.core

import java.io.InputStream
import java.security.MessageDigest

/**
 * Computes the SHA-1 a file would have as a Git blob.
 *
 * Git hashes `"blob <byteCount>\u0000" + contents`, so the value can be compared
 * against the SHAs in a remote tree to decide whether a file needs uploading at
 * all. This is what makes re-uploading a large folder fast.
 */
object GitHash {

    private const val BUFFER = 1 shl 20 // 1 MiB

    fun blobSha(stream: InputStream, size: Long): String {
        val digest = MessageDigest.getInstance("SHA-1")
        digest.update("blob $size\u0000".toByteArray(Charsets.US_ASCII))

        val buffer = ByteArray(BUFFER)
        stream.use { input ->
            while (true) {
                val read = input.read(buffer)
                if (read <= 0) break
                digest.update(buffer, 0, read)
            }
        }
        return digest.digest().joinToString("") { "%02x".format(it) }
    }

    fun blobSha(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-1")
        digest.update("blob ${bytes.size}\u0000".toByteArray(Charsets.US_ASCII))
        digest.update(bytes)
        return digest.digest().joinToString("") { "%02x".format(it) }
    }
}
