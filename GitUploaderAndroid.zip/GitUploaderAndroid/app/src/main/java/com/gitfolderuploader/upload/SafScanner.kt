package com.gitfolderuploader.upload

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.core.GitHash
import com.gitfolderuploader.domain.model.UploadFile
import com.gitfolderuploader.domain.model.UploadSource
import com.gitfolderuploader.data.remote.GitHubService

/**
 * Reads picked files and folders through the Storage Access Framework.
 *
 * Why SAF rather than raw file paths
 * ----------------------------------
 * `ACTION_OPEN_DOCUMENT_TREE` plus `takePersistableUriPermission` grants access
 * to a folder that **survives process death and reboot**. Nothing has to be
 * copied into the app's own storage, and a job paused today can resume next
 * week against the original files. This is the piece iOS has no equivalent of,
 * and the reason folder upload is straightforward here.
 *
 * The tree is walked with `DocumentsContract` queries rather than
 * `DocumentFile.listFiles()`. `DocumentFile` issues one query per attribute per
 * child, which turns a few thousand files into tens of thousands of IPC calls;
 * querying the columns directly keeps a large project scan to a few seconds.
 */
object SafScanner {

    /** Directories that never belong in a repository. */
    private val excludedDirs = setOf(
        ".git", "node_modules", ".gradle", "build", ".idea", "DerivedData",
        "__pycache__", ".dart_tool", ".venv", "Pods"
    )

    private val excludedFiles = setOf(".DS_Store", "Thumbs.db", ".gitkeep.tmp")

    data class ScanResult(
        val files: List<UploadFile> = emptyList(),
        val totalBytes: Long = 0,
        /** Files above GitHub's blob ceiling; reported, never silently dropped. */
        val oversized: List<String> = emptyList(),
        val unreadable: List<String> = emptyList()
    )

    /** Flags that must be taken for a grant to persist across reboots. */
    const val PERSIST_FLAGS =
        Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION

    /**
     * Records a permanent claim on a picked URI.
     *
     * Android caps the number of persisted URIs per app (128 on most builds),
     * so failures here are logged rather than thrown: the upload still works
     * for the current session even when the claim cannot be kept.
     */
    fun persist(context: Context, uri: Uri, isTree: Boolean) {
        val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
        runCatching {
            context.contentResolver.takePersistableUriPermission(uri, flags)
            AppLog.picker("Persisted permission for $uri (tree=$isTree)")
        }.onFailure {
            AppLog.pickerError("Could not persist permission for $uri", it)
        }
    }

    /** True when the app still holds a persisted grant for this URI. */
    fun hasPersistedPermission(context: Context, uri: Uri): Boolean =
        context.contentResolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission
        }

    /**
     * Builds an [UploadSource] from a URI returned by the system picker.
     *
     * @param isTree true for `ACTION_OPEN_DOCUMENT_TREE` results.
     */
    fun describe(context: Context, uri: Uri, isTree: Boolean): UploadSource? {
        persist(context, uri, isTree)

        val name = if (isTree) treeDisplayName(context, uri) else documentDisplayName(context, uri)
        if (name == null) {
            AppLog.pickerError("Could not read a display name for $uri")
            return null
        }
        AppLog.picker("Described ${if (isTree) "folder" else "file"} '$name' from $uri")
        return UploadSource(uri = uri.toString(), displayName = name, isFolder = isTree)
    }

    /**
     * Scans every source, computing each file's Git blob SHA-1.
     *
     * @param prefixWithSourceName when true each folder's contents are nested
     *   under its own name. Used when several items were picked at once so two
     *   folders cannot overwrite each other.
     */
    fun scan(
        context: Context,
        sources: List<UploadSource>,
        prefixWithSourceName: Boolean,
        onProgress: ((Int) -> Unit)? = null
    ): ScanResult {
        val files = mutableListOf<UploadFile>()
        val oversized = mutableListOf<String>()
        val unreadable = mutableListOf<String>()
        val taken = mutableSetOf<String>()
        var totalBytes = 0L

        for (source in sources) {
            val uri = Uri.parse(source.uri)
            val prefix = if (prefixWithSourceName && source.isFolder) source.displayName else ""

            if (source.isFolder) {
                val rootDocId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull()
                if (rootDocId == null) {
                    AppLog.pickerError("[${source.displayName}] not a tree URI")
                    unreadable += source.displayName
                    continue
                }
                walk(
                    context = context,
                    treeUri = uri,
                    documentId = rootDocId,
                    relativePrefix = prefix,
                    files = files,
                    oversized = oversized,
                    unreadable = unreadable,
                    taken = taken,
                    onTotal = { totalBytes += it },
                    onProgress = onProgress
                )
            } else {
                val single = readSingle(context, uri, source.displayName, prefix, taken)
                when {
                    single == null -> unreadable += source.displayName
                    single.size > GitHubService.MAX_BLOB_BYTES -> oversized += source.displayName
                    else -> {
                        files += single
                        totalBytes += single.size
                        onProgress?.invoke(files.size)
                    }
                }
            }
        }

        AppLog.picker("Scan finished: ${files.size} file(s), ${oversized.size} oversized, ${unreadable.size} unreadable")
        return ScanResult(
            files = files.sortedBy { it.relativePath },
            totalBytes = totalBytes,
            oversized = oversized,
            unreadable = unreadable
        )
    }

    /** Depth-first walk of one document tree, hierarchy preserved. */
    private fun walk(
        context: Context,
        treeUri: Uri,
        documentId: String,
        relativePrefix: String,
        files: MutableList<UploadFile>,
        oversized: MutableList<String>,
        unreadable: MutableList<String>,
        taken: MutableSet<String>,
        onTotal: (Long) -> Unit,
        onProgress: ((Int) -> Unit)?
    ) {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE,
            DocumentsContract.Document.COLUMN_SIZE
        )

        val cursor: Cursor = runCatching {
            context.contentResolver.query(childrenUri, projection, null, null, null)
        }.getOrNull() ?: run {
            AppLog.pickerError("Could not list children of $documentId")
            unreadable += relativePrefix.ifEmpty { documentId }
            return
        }

        cursor.use {
            while (it.moveToNext()) {
                val childId = it.getString(0)
                val name = it.getString(1) ?: continue
                val mime = it.getString(2)
                val size = if (it.isNull(3)) 0L else it.getLong(3)
                val isDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR

                val childPath = if (relativePrefix.isEmpty()) name else "$relativePrefix/$name"

                if (isDirectory) {
                    if (name in excludedDirs) {
                        AppLog.picker("Skipping excluded directory $childPath")
                        continue
                    }
                    walk(
                        context, treeUri, childId, childPath,
                        files, oversized, unreadable, taken, onTotal, onProgress
                    )
                    continue
                }

                if (name in excludedFiles) continue
                if (size > GitHubService.MAX_BLOB_BYTES) {
                    oversized += childPath
                    continue
                }

                val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, childId)
                val sha = hashOf(context.contentResolver, documentUri, size)
                if (sha == null) {
                    unreadable += childPath
                    continue
                }

                val unique = freePath(childPath, taken)
                taken += unique
                files += UploadFile(
                    relativePath = unique,
                    uri = documentUri.toString(),
                    size = size,
                    gitSha = sha
                )
                onTotal(size)
                onProgress?.invoke(files.size)
            }
        }
    }

    private fun readSingle(
        context: Context,
        uri: Uri,
        displayName: String,
        prefix: String,
        taken: MutableSet<String>
    ): UploadFile? {
        val size = documentSize(context, uri) ?: return null
        val sha = hashOf(context.contentResolver, uri, size) ?: return null
        val path = if (prefix.isEmpty()) displayName else "$prefix/$displayName"
        val unique = freePath(path, taken)
        taken += unique
        return UploadFile(relativePath = unique, uri = uri.toString(), size = size, gitSha = sha)
    }

    /**
     * Streams the file once to compute its Git blob SHA-1.
     *
     * The stream is read in 1 MiB chunks so a large file never lands in memory.
     */
    private fun hashOf(resolver: ContentResolver, uri: Uri, size: Long): String? = runCatching {
        resolver.openInputStream(uri)?.use { GitHash.blobSha(it, size) }
    }.getOrElse {
        AppLog.pickerError("Hashing failed for $uri", it)
        null
    }

    fun documentSize(context: Context, uri: Uri): Long? = queryColumn(context, uri) { cursor ->
        val index = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE)
        if (index >= 0 && !cursor.isNull(index)) cursor.getLong(index) else 0L
    }

    private fun documentDisplayName(context: Context, uri: Uri): String? =
        queryColumn(context, uri) { cursor ->
            val index = cursor.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            if (index >= 0) cursor.getString(index) else null
        }

    private fun treeDisplayName(context: Context, treeUri: Uri): String? {
        val documentId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull()
            ?: return null
        val documentUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId)
        return documentDisplayName(context, documentUri)
            // Some providers omit the display name; the tail of the document id
            // is the folder name in every provider that does this.
            ?: documentId.substringAfterLast('/').substringAfterLast(':').ifBlank { null }
    }

    private fun <T> queryColumn(context: Context, uri: Uri, read: (Cursor) -> T?): T? = runCatching {
        context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) read(cursor) else null
        }
    }.getOrElse {
        AppLog.pickerError("Metadata query failed for $uri", it)
        null
    }

    /** Gives a colliding path a free name: `notes.txt` becomes `notes (2).txt`. */
    fun freePath(path: String, taken: Set<String>): String {
        if (path !in taken) return path
        val extension = path.substringAfterLast('.', "")
        val stem = if (extension.isEmpty()) path else path.substring(0, path.length - extension.length - 1)
        var counter = 2
        while (counter < 1000) {
            val candidate = if (extension.isEmpty()) "$stem ($counter)" else "$stem ($counter).$extension"
            if (candidate !in taken) return candidate
            counter++
        }
        return "$stem-${System.nanoTime()}" + if (extension.isEmpty()) "" else ".$extension"
    }
}
