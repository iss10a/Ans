package com.gitfolderuploader.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.gitfolderuploader.GitApp
import com.gitfolderuploader.R
import com.gitfolderuploader.core.Formatters
import com.gitfolderuploader.domain.model.FileState
import com.gitfolderuploader.domain.model.UploadFile

/** Live view of one job: overall progress, speed, and every file's own bar. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun JobDetailScreen(app: GitApp, jobId: String, onBack: () -> Unit) {

    val jobs by app.uploads.jobs.collectAsState()
    val job = jobs.firstOrNull { it.id == jobId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(job?.displayName ?: stringResource(R.string.tab_uploads)) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
                }
            )
        }
    ) { padding ->
        if (job == null) {
            Centered { Text(stringResource(R.string.uploads_empty)) }
            return@Scaffold
        }

        LazyColumn(Modifier.fillMaxSize().padding(padding)) {
            item {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("${job.repo.fullName} · ${job.branch}", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        text = if (job.remoteRoot.isEmpty()) "/" else "/${job.remoteRoot}",
                        fontFamily = FontFamily.Monospace,
                        style = MaterialTheme.typography.labelMedium
                    )

                    LinearProgressIndicator(
                        progress = { job.fraction.toFloat() },
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                    )

                    Text(
                        text = "${stateLabel(job.state)} · ${Formatters.percent(job.fraction)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(
                        text = "${job.settledFiles}/${job.totalFiles} · " +
                            "${Formatters.size(job.transferredBytes)} / ${Formatters.size(job.transferableBytes)}",
                        style = MaterialTheme.typography.labelSmall
                    )
                    job.bytesPerSecond?.let {
                        Text(
                            text = Formatters.speed(it) + (job.secondsRemaining?.let { s ->
                                " · " + Formatters.duration(s)
                            } ?: ""),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    if (job.skippedFiles > 0) {
                        Text(
                            text = stringResource(R.string.upload_unchanged_count, job.skippedFiles),
                            style = MaterialTheme.typography.labelSmall
                        )
                    }
                    job.lastError?.let {
                        Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    }
                    job.resultCommitSha?.takeIf { it.isNotBlank() }?.let {
                        Text(
                            text = stringResource(R.string.upload_commit) + ": " + it.take(10),
                            fontFamily = FontFamily.Monospace,
                            style = MaterialTheme.typography.labelSmall
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (job.state.isActive) {
                            Button(onClick = { app.uploads.pause(job.id) }) {
                                Text(stringResource(R.string.upload_pause))
                            }
                        }
                        if (job.state.isResumable) {
                            Button(onClick = { app.uploads.resume(job.id) }) {
                                Text(stringResource(R.string.upload_resume))
                            }
                        }
                        if (!job.state.isTerminal) {
                            TextButton(onClick = { app.uploads.cancel(job.id) }) {
                                Text(stringResource(R.string.common_cancel))
                            }
                        }
                        TextButton(onClick = { app.uploads.remove(job.id); onBack() }) {
                            Text(stringResource(R.string.common_remove))
                        }
                    }
                }
                HorizontalDivider()
            }

            items(job.files.take(500), key = { it.relativePath }) { file ->
                FileRow(file)
                HorizontalDivider()
            }

            if (job.files.size > 500) {
                item {
                    Text(
                        text = stringResource(R.string.upload_truncated, job.files.size - 500),
                        style = MaterialTheme.typography.labelSmall,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun FileRow(file: UploadFile) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            text = file.relativePath,
            fontFamily = FontFamily.Monospace,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = buildString {
                append(fileStateLabel(file.state))
                append(" · ")
                append(Formatters.size(file.size))
                if (file.state == FileState.UPLOADING) {
                    append(" · ")
                    append(Formatters.size(file.bytesSent))
                }
                file.renamedRelativePath?.let { append(" · renamed") }
            },
            style = MaterialTheme.typography.labelSmall
        )
        if (file.state == FileState.UPLOADING) {
            LinearProgressIndicator(
                progress = { file.fraction.toFloat() },
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
            )
        }
        file.errorMessage?.let {
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun fileStateLabel(state: FileState): String = when (state) {
    FileState.PENDING -> stringResource(R.string.file_pending)
    FileState.UPLOADING -> stringResource(R.string.file_uploading)
    FileState.UPLOADED -> stringResource(R.string.file_uploaded)
    FileState.SKIPPED -> stringResource(R.string.file_skipped)
    FileState.FAILED -> stringResource(R.string.file_failed)
}
