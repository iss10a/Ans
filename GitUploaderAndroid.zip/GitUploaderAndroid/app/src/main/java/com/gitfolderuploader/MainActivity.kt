package com.gitfolderuploader

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gitfolderuploader.ui.screens.BrowserScreen
import com.gitfolderuploader.ui.screens.HomeScreen
import com.gitfolderuploader.ui.screens.JobDetailScreen
import com.gitfolderuploader.ui.screens.LoginScreen
import com.gitfolderuploader.ui.theme.GitUploaderTheme
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val app: GitApp get() = application as GitApp

    /**
     * Applies the in-app language before any view is created.
     *
     * Wrapping the base context is what makes the Arabic switch take effect
     * without asking the user to change the whole device language, and it also
     * flips the layout direction because `ar` is a right-to-left locale.
     */
    override fun attachBaseContext(newBase: Context) {
        val settings = com.gitfolderuploader.core.Settings(newBase)
        super.attachBaseContext(applyLanguage(newBase, settings.language))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            var theme by remember { mutableStateOf(app.settings.theme) }

            GitUploaderTheme(themeSetting = theme) {
                val navController = rememberNavController()
                val start = if (app.tokens.token.isNullOrBlank()) "login" else "home"

                NavHost(navController = navController, startDestination = start) {
                    composable("login") {
                        LoginScreen(app = app, onSignedIn = {
                            navController.navigate("home") {
                                popUpTo("login") { inclusive = true }
                            }
                        })
                    }

                    composable("home") {
                        HomeScreen(
                            app = app,
                            onOpenRepository = { repo, branch, path ->
                                navController.navigate("browser/$repo/$branch/${encode(path)}")
                            },
                            onOpenJob = { id -> navController.navigate("job/$id") },
                            onSignOut = {
                                app.tokens.clear()
                                navController.navigate("login") {
                                    popUpTo("home") { inclusive = true }
                                }
                            },
                            onThemeChanged = { value ->
                                app.settings.theme = value
                                theme = value
                            },
                            onLanguageChanged = { value ->
                                app.settings.language = value
                                recreate()
                            }
                        )
                    }

                    composable("browser/{repo}/{branch}/{path}") { entry ->
                        BrowserScreen(
                            app = app,
                            fullName = entry.arguments?.getString("repo").orEmpty(),
                            branch = entry.arguments?.getString("branch").orEmpty(),
                            path = decode(entry.arguments?.getString("path").orEmpty()),
                            onOpenFolder = { repo, branch, path ->
                                navController.navigate("browser/$repo/$branch/${encode(path)}")
                            },
                            onBack = { navController.popBackStack() },
                            onOpenQueue = { navController.navigate("home") }
                        )
                    }

                    composable("job/{id}") { entry ->
                        JobDetailScreen(
                            app = app,
                            jobId = entry.arguments?.getString("id").orEmpty(),
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }

    private companion object {
        /** Navigation arguments cannot contain raw slashes. */
        fun encode(path: String) = if (path.isEmpty()) "~" else path.replace("/", "\u2044")

        fun decode(path: String) = if (path == "~") "" else path.replace("\u2044", "/")

        fun applyLanguage(context: Context, language: String): Context {
            if (language == "system") return context
            val locale = Locale(language)
            Locale.setDefault(locale)
            val configuration = Configuration(context.resources.configuration)
            configuration.setLocale(locale)
            configuration.setLayoutDirection(locale)
            return context.createConfigurationContext(configuration)
        }
    }
}
