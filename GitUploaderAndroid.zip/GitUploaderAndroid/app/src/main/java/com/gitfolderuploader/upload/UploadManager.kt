package com.gitfolderuploader.upload

import android.content.Context
import android.content.Intent
import android.os.Build
import com.gitfolderuploader.core.AppLog
import com.gitfolderuploader.domain.model.FileState
import com.gitfolderuploader.domain.model.JobState
import com.gitfolderuploader.domain.model.UploadJob
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * The shared upload queue.
 *
 * One job runs at a time — each already parallelises its own blob uploads, so
 * running two would only fragment bandwidth and multiply rate-limit pressure.
 * State is written to disk after every change, and a foreground service keeps
 * the process alive while a transfer is in flight.
 */
class UploadManager(
    private val context: Context,
    private val engine: UploadEngine,
    private val store: JobStore
) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val watcher = NetworkWatcher(context)

    private val _jobs = MutableStateFlow<List<UploadJob>>(emptyList())
    val jobs: StateFlow<List<UploadJob>> = _jobs.asStateFlow()

    private val _runningJobId = MutableStateFlow<String?>(null)
    val runningJobId: StateFlow<String?> = _runningJobId.asStateFlow()

    private val _isOffline = MutableStateFlow(false)
    val isOffline: StateFlow<Boolean> = _isOffline.asStateFlow()

    private var runner: Job? = null

    /** Jobs paused by a dropped connection; these resume without user action. */
    private val pausedByNetwork = mutableSetOf<String>()

    val activeJobs: List<UploadJob> get() = _jobs.value.filter { !it.state.isTerminal }
    val finishedJobs: List<UploadJob> get() = _jobs.value.filter { it.state.isTerminal }
    val hasResumableWork: Boolean get() = _jobs.value.any { it.state.isResumable }

    fun start() {
        reload()
        watcher.start(
            onAvailable = {
                _isOffline.value = false
                resumeAfterReconnect()
            },
            onLost = {
                _isOffline.value = true
                pauseForConnectionLoss()
            }
        )
    }

    fun reload() {
        // A job marked "uploading" when the process died is really paused.
        val loaded = store.loadAll().map { job ->
            if (job.state.isActive) {
                job.state = JobState.PAUSED
                job.files.forEach { file ->
                    if (file.state == FileState.UPLOADING) {
                        file.state = FileState.PENDING
                        file.bytesSent = 0
                    }
                }
                store.save(job)
            }
            job
        }
        _jobs.value = loaded
    }

    fun job(id: String): UploadJob? = _jobs.value.firstOrNull { it.id == id }

    // ------------------------------------------------------------- Queueing

    fun enqueue(job: UploadJob) {
        store.save(job)
        _jobs.value = _jobs.value + job
        AppLog.upload("Queued job ${job.id} (${job.displayName})")
        startNextIfIdle()
    }

    fun resume(id: String) {
        val job = job(id) ?: return
        if (!job.state.isResumable) return
        job.state = JobState.QUEUED
        job.lastError = null
        job.files.forEach { file ->
            if (file.state == FileState.FAILED) {
                file.state = FileState.PENDING
                file.errorMessage = null
            }
        }
        persistAndPublish(job)
        startNextIfIdle()
    }

    fun resumeAll() {
        _jobs.value.filter { it.state.isResumable }.forEach { resume(it.id) }
    }

    fun pause(id: String) {
        pausedByNetwork.remove(id)
        if (_runningJobId.value == id) {
            runner?.cancel()
        } else {
            job(id)?.let {
                it.state = JobState.PAUSED
                persistAndPublish(it)
            }
        }
    }

    fun cancel(id: String) {
        pausedByNetwork.remove(id)
        if (_runningJobId.value == id) runner?.cancel()
        job(id)?.let {
            it.state = JobState.CANCELLED
            persistAndPublish(it)
        }
    }

    fun remove(id: String) {
        if (_runningJobId.value == id) runner?.cancel()
        pausedByNetwork.remove(id)
        store.delete(id)
        _jobs.value = _jobs.value.filterNot { it.id == id }
    }

    fun clearFinished() {
        finishedJobs.forEach { store.delete(it.id) }
        _jobs.value = _jobs.value.filterNot { it.state.isTerminal }
    }

    fun cancelAll() {
        pausedByNetwork.clear()
        runner?.cancel()
        _jobs.value.filter { !it.state.isTerminal }.forEach {
            it.state = JobState.CANCELLED
            store.save(it)
        }
        _jobs.value = _jobs.value.toList()
    }

    // -------------------------------------------------------------- Running

    fun startNextIfIdle() {
        if (runner?.isActive == true) return
        val next = _jobs.value.firstOrNull { it.state == JobState.QUEUED } ?: run {
            stopService()
            return
        }
        _runningJobId.value = next.id
        startService()

        runner = scope.launch {
            try {
                engine.execute(next) { updated -> persistAndPublish(updated) }
            } finally {
                _runningJobId.value = null
                // Cancellation without an explicit terminal state means paused.
                if (next.state.isActive) {
                    next.state = JobState.PAUSED
                    persistAndPublish(next)
                }
                startNextIfIdle()
            }
        }
    }

    private fun persistAndPublish(job: UploadJob) {
        store.save(job)
        // The list holds the same instances, so a new list reference is what
        // makes Compose recompose.
        _jobs.value = _jobs.value.map { if (it.id == job.id) job else it }
    }

    // ---------------------------------------------------------- Reachability

    private fun pauseForConnectionLoss() {
        val running = _runningJobId.value ?: return
        AppLog.upload("Pausing $running until the connection returns")
        pausedByNetwork += running
        runner?.cancel()
    }

    private fun resumeAfterReconnect() {
        if (pausedByNetwork.isEmpty() && !hasResumableWork) return
        AppLog.upload("Resuming ${pausedByNetwork.size} job(s) after reconnect")
        pausedByNetwork.toList().forEach { resume(it) }
        pausedByNetwork.clear()
        startNextIfIdle()
    }

    // -------------------------------------------------------------- Service

    private fun startService() {
        val intent = Intent(context, UploadService::class.java)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }.onFailure { AppLog.uploadError("Could not start the upload service", it) }
    }

    private fun stopService() {
        runCatching { context.stopService(Intent(context, UploadService::class.java)) }
    }

    /** Combined progress of everything still in flight, for the tab badge. */
    val overallFraction: Double
        get() {
            val active = activeJobs
            if (active.isEmpty()) return 0.0
            return active.sumOf { it.fraction } / active.size
        }
}
